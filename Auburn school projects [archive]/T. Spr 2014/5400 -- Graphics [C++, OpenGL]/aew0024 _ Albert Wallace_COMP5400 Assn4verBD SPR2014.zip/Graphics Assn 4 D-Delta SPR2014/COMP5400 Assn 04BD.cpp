
/*Auburn University Student Center, plus mobile person. */
/*	COMP5400 Assignment #04 ver BD, directly from Assn 03 ver _C (replaces 04-A) */
/*Albert Wallace, aew0024, 07, 13, 14 February 2014; 2/27, 3/1, 3/3, 3/4, 3/17, 3/18, 3/19/2014                        */
/*outside code assistance, if required, noted in the code itself*/


/********************************************************************************
 *TO CONTROL the digital person (D.P.), these USER CONTROLS are available:
 ********************************************************************************/
/*
---0 key increases D.P.'s size, 1 key decreases D.P.'s size (minimum size is default, maximum is undefined and he WILL begin to disappear once he grows too big)
---8 key increases the field of view in the Y direction, 7 key decreases the field of view (zooms out and in, respectively)
---Left and right arrow keys rotate D.P. as if the feet were on a spinning platform
---		(the camera remains with D.P., always looking at his back so you can see ahead)
---Up and Down arrow keys result in moving forward or backward, respectively, relative to camera position
---4 key renders animation for 100 cycles then stops (allegedly). 5 key, when held down, forces animation.
---See "OTHER COMMENTS" below.
*/

//############# OTHER COMMENTS: ######################################
//D.P. walks around on the XZ plane, with the positive Y axis representing the normal vector for the entire visible world. 
//   ...If he gets too big, he may sink. If he gets too small, he may float. He is made of magic. 
//   ...(Scaling doesn't take into account the translation needed to get him to the right position by default).
//Butterflies never change their body rotation, so they will appear to fly sideways about half of the time.
//The bodies of the people are somewhat transparent/glitchy. No attempts were made to fix them, as they are unimportant.
//The wings of the butterflies have nothing in them. This is a known fact, and is accepted as a new breed of butterfly.
//The pathing functions will send the people and the butterflies through the student center. This is accepted, as they are ghosts.
//People and butterflies will only move when you move D.P. (or press the unassigned button listed above), including when you modify his rotation and scaling. Every button press drives them in their animation.
//   ...For the remainder of the time, they are frozen in position. They are time lords, and you should not even be seeing them.
//You are allowed to walk through the building, you are allowed to walk off the edge of the world, and you are allowed to walk through people.
//   ...It's not your magic; I just like the effect.
//You can never view D.P.'s face by default. There is no mirror, and there is no way to detach the camera from the rear view.
//   ...This is by design, and makes the focus be on his abilities rather than on his appearance.
//   ...(But the appearance of the other people very much matters, as is the case in life. That's why they look wonky.)


//Unnecessary header files now no longer included.
//Use of sqrt function changes after exclusion of previously included header files, due to multiple overloaded versions. Fix now implemented.

#include <stdlib.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <math.h>

#define PI 3.141592653589739

//colors for trees
const int PINK = 1;
const int GREEN = 2;
const int BLUE = 3;
const int YELLOW = 4;
const int OTHER = 5;

//more variables
float sbr = 2; //LEGACY; ratio by which to scale select values; unused in newer code, soon to be deprecated
float denomRGB = 255; //to convert from 8-bit representation to float representation
float thetaChangeMagnitude = 2.5f; //used to decide how much a person rotates, in degrees, upon each arrow press
float thetaToRotatePerson = 180.0f;
float currentXCoordinate = 0.0f; //current X coordinate of the center of the face and camera; original value defines the starting point
float currentZCoordinate = 150.0f; //current Y coordinate of the center of the face and camera; original value defines the starting point
float thetaMultiplier = 1.000f; //can be used to speed up or slow down the rotation of the man relative to the camera
float scaleChangeMagnitude = 0.2f; //additive value, helping to control the act of shrinking or growing D.P. with the keyboard keys defined above for scaling up and down; affects the scaling value which itself is multiplicative
float currentScalingMagnitude = 0.5f; //the value ultimately affected by the scaleChangeMagnitude during user input, used to scale D.P. up or down. Should never be zero.
float riseY = 0.0f; //dictates how far to move along the appropriate axis (not the Y axis...refer to each individual use! Expect it to affect the X axis.), whether positive or negative; original value defines initial movement with up & down arrows
float runX = -2.0f; //dictates how far to move along the appropriate axis (not the X axis...refer to each individual use! Excpect it to affect the Z axis.), whether positive or negative; original value defines initial movement with up & down arrows
float originalFieldOfViewY = 75.0f; //defines the initial config for the field of view; defines the min/max
float currentFieldOfViewY = originalFieldOfViewY; //the current setting for the field of view
float fieldOfViewDelta = 2.0f; //defines the increment or decrement steps when using keys 7/8


//values for animation of random people
int helperForPositionOfLegs = 0;
float pathingLengthHalved = 2500; //half of the desired travel of one bystander along a given axis (X or Z) (bystanders travel along a box-like path)
float bystanderAPosX = 0, bystanderAPosZ = pathingLengthHalved + 2, bystanderBPosX = 150, bystanderBPosZ = pathingLengthHalved+ 2, bystanderCPosX = 450, bystanderCPosZ = pathingLengthHalved + 2;
float bystanderAngleA = 90, bystanderAngleB = 90, bystanderAngleC = 90;

//and for the butterflies
bool wingReverse = false;
float flapDegrees = 0;
float butterflyAPosX = -600, butterflyAPosY = 0, butterflyAPosZ = pathingLengthHalved + 2, butterflyBPosX = -150, butterflyBPosY = 0, butterflyBPosZ = pathingLengthHalved+ 2, butterflyCPosX = -450, butterflyCPosY = 0, butterflyCPosZ = pathingLengthHalved + 2;
bool butterflyAZig = false, butterflyBZig = true, butterflyCZig = false;

GLubyte stippleStyleFine[] = {
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA /* 10....10 10....10 10....10 10....10*/
}; //GLubyte stippleStyleFine[]

GLubyte stippleStyleStripe[] = {
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
}; //GLubyte stippleStyleStripe[]

GLubyte stippleStyleBrick[] = {
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
}; //GLubyte stippleStyleBrick[]


void buildGLRectangle(float xMin, float xMax, float yMin, float yMax) //used to speed up the creation of a GL QUAD that will only be a rectangle or square
{
	glBegin(GL_QUADS); 
		glVertex2f(xMin*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMax*sbr);
		glVertex2f(xMin*sbr,yMax*sbr);
	glEnd();
}

void makeASun(float radius)

{
	glColor3f((float)255.0/255.0,(float)211.0/255.0,(float)79.0/255.0);
	int quality = 100;
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	gluSphere(quadric, radius, quality,quality);
}


void surfbort() //the easter egg code which prints the word "surfbort" on a banner. Can be treated as an entire object, like the build... functions below.
{
	glColor3f(.1,.1,.1);
	buildGLRectangle(-200,200,-50,50);
	glColor3f(1,1,1);
	glBegin(GL_LINE_STRIP);
		glVertex3f(-175,45,0.1);
		glVertex3f(-195,45,0.1);
		glVertex3f(-195,3,0.1);
		glVertex3f(-175,3,0.1);
		glVertex3f(-175,-40,0.1);
		glVertex3f(-195,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-160,45,0.1);
		glVertex3f(-160,-40,0.1);
		glVertex3f(-135,-40,0.1);
		glVertex3f(-135,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-120,-40,0.1);
		glVertex3f(-120,45,0.1);
		glVertex3f(-90,45,0.1);
		glVertex3f(-90,2,0.1);
		glVertex3f(-120,2,0.1);
		glVertex3f(-90,-40,0.1);
	glEnd();
	
	glBegin(GL_LINE_STRIP);
		glVertex3f(-80,-40,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-40,45,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-80,2,0.1);
		glVertex3f(-45,2,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-35,45,0.1);
		glVertex3f(-35,-40,0.1);
		glVertex3f(-5,-40,0.1);
		glVertex3f(-35,2,0.1);
		glVertex3f(-5,2,0.1);
		glVertex3f(-5,45,0.1);
		glVertex3f(-35,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(0,45,0.1);
		glVertex3f(0,-40,0.1);
		glVertex3f(30,-40,0.1);
		glVertex3f(30,45,0.1);
		glVertex3f(0,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(40,-40,0.1);
		glVertex3f(40,45,0.1);
		glVertex3f(70,45,0.1);
		glVertex3f(70,2,0.1);
		glVertex3f(40,2,0.1);
		glVertex3f(70,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(80,45,0.1);
		glVertex3f(110,45,0.1);
		glVertex3f(95,45,0.1);
		glVertex3f(95,-40,0.1);
	glEnd();
	
}

void buildFakeLogo(float lengthOfSides) //this is the test cube, aka the logo, that happens to be shown in the lower left
{
	//face one -- parallel to XY plane, positive
	glColor3f(1,1,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	glColor3f(0,0.40,0);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face four --parallel to YZ plane, negative
	glColor3f(0,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	glColor3f(0.80,0.80,0);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}

void buildGLCube(float lengthOfSides)
{
	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}

void buildGLBrick(float width, float height, float depth)
{
	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
	glEnd();
}

void buildEquilateralTriangle(float lengthOfSide)
{
	glBegin(GL_TRIANGLES);
		glVertex3f(0,0,0);
		glVertex3f(-0.5*lengthOfSide,-.5*lengthOfSide*sqrt((float)3.0),0);
		glVertex3f(0.5*lengthOfSide,-.5*lengthOfSide*sqrt((float)3.0),0);
	glEnd();
}

void checkPathing(float * personXPosition, float * personZPosition, float * personAngle)
{
	float changePositionParamsBy = 10; //by how much to move each person along its respective axis
	if (*personXPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 0;
		*personZPosition += changePositionParamsBy;
	}
	if (*personZPosition > pathingLengthHalved + 1)
	{
		*personAngle = 90;
		*personXPosition += changePositionParamsBy;
	}
	if (*personXPosition > pathingLengthHalved + 1)
	{
		*personAngle = 180;
		*personZPosition -= changePositionParamsBy;
	}
	if (*personZPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 270;
		*personXPosition -= changePositionParamsBy;
	}
	if (*personAngle >= (float)360)
		*personAngle = (float)0;
}

void checkPathingButterfly(float * butterflyX, float * butterflyY, float * butterflyZ, bool * zigNotZag)
{
	float changeinY = 1;
	float maxHeightOfFlight = 100;

	
	float changePositionParamsBy = 10; //by how much to move each person along its respective axis
	//float pathingLengthHalved = 1700;

	if (*butterflyX < -1 * (pathingLengthHalved + 1))
	{
		*butterflyZ += changePositionParamsBy;
	}
	if (*butterflyZ > pathingLengthHalved + 1)
	{
		*butterflyX += changePositionParamsBy;
	}
	if (*butterflyX > pathingLengthHalved + 1)
	{
		*butterflyZ -= changePositionParamsBy;
	}
	if (*butterflyZ < -1 * (pathingLengthHalved + 1))
	{
		*butterflyX -= changePositionParamsBy;
	}
	if (*zigNotZag)
	{
		*butterflyY += changeinY;
		if (*butterflyY > maxHeightOfFlight)
		{
			*zigNotZag = false;
		}
	}
	else if (!*zigNotZag)
	{
		*butterflyY -= changeinY;
		if (*butterflyY < -maxHeightOfFlight)
		{
			*zigNotZag = true;
		}
	}
}

void butterfly()
{
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	double radiusOfWing = 50;
	double thicknessOfWing = 10;
	int wingQuality = 20;
	
	glColor4f(0,0,(float)0.5,1); //this is the nice shade of blue

	//the wings

	if (wingReverse)
	{
		flapDegrees -= 1.0;
		if (flapDegrees < -90)
		{
			flapDegrees = -90;
			wingReverse = false;
		}
	}
	else if (!wingReverse)
	{
		flapDegrees += 1.0;
		if (flapDegrees > 90)
		{
			flapDegrees = 90;
			wingReverse = true;
		}
	}

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleStripe);
	glPushMatrix();
		glRotatef(flapDegrees,0,0,1);
		glTranslatef(radiusOfWing,0,0);
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfWing, radiusOfWing, thicknessOfWing, wingQuality, wingQuality);
	glPopMatrix();
	glPushMatrix();
		glRotatef(-flapDegrees,0,0,1);
		glTranslatef(-radiusOfWing,0,0);
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfWing, radiusOfWing, thicknessOfWing, wingQuality, wingQuality);
	glPopMatrix();
	glDisable(GL_POLYGON_STIPPLE);

	//and the body
	buildGLBrick((float)10,(float)20,2.5*radiusOfWing);
}

void buildBlockyStudentCenter(void)
{
	float ssAlphaValue = 1.0;
	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleBrick);
	//glColor4f(0,0,(float)0.5,ssAlphaValue); //this is the nice shade of blue you miss
	//glColor4f(.7,.11,.7, ssAlphaValue);
	glColor4f((float)130.0/255.0,(float)43/255.0,0, ssAlphaValue);
	glPushMatrix();
		glTranslatef(-200,300,-400);
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.6,.10,.6,ssAlphaValue);
	//glColor4f(.9,.9,.9, ssAlphaValue);
	glPushMatrix();
		glTranslatef(0,300,-300);
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.7,.11,.7,ssAlphaValue);
	//glColor4f(.8,.8,.8, ssAlphaValue);
	glPushMatrix();
		glTranslatef(300,300,-400);
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.6,.10,.0,ssAlphaValue);
	//glColor4f(.7,.7,.7, ssAlphaValue);
	glPushMatrix();
		glTranslatef(200,500,-700);
		buildGLCube(1000);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,300,-1100);
		buildGLCube(600);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,600,-1400);
		buildGLCube(1200);
	glPopMatrix();

	
	glPushMatrix();
		glTranslatef(-200,600,-2100);
		buildGLBrick(800,1200,600);
		//buildGLCube(800);
	glPopMatrix();


	glPushMatrix();
		glTranslatef(600,700,-1350);
		buildGLCube(700);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(600,700,-850);
		buildGLCube(700);
	glPopMatrix();

	//glColor4f(0,0,(float)0.5,(float)0.5);
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	double radiusOfCylinder = 300;
	int quality = 25;
	glPushMatrix();
		glTranslatef(0,4.0*radiusOfCylinder,-2500);
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfCylinder, radiusOfCylinder, 4.0*radiusOfCylinder, quality, quality);
	glPopMatrix();


	glDisable(GL_POLYGON_STIPPLE);
}

void buildFakeApple(void) //create a fake Apple logo
{
	glPushMatrix();
		glColor3f(1,1,1);
		buildGLBrick(60,60,4);
		glTranslatef(20,0,0);
		glColor3f(.2,.2,.5);
		buildGLBrick(20,20,4.1);
		glTranslatef(-20,0,0);
		glTranslatef(5,48,0);
		glColor3f(1,1,1);
		glRotatef(-45,0,0,1);
		buildGLBrick(10,28,4);
	glPopMatrix();
}

void buildHeadphones()
{
	glPushMatrix();
		glTranslatef(70,0,0);
		buildGLCube(50); //one cup
		glTranslatef(-140,0,0);
		buildGLCube(50); //the other cup
		glTranslatef(0,25 + 25,0);
		buildGLBrick(20,50,30); //upper band for one cup
		glTranslatef(140,0,0);
		buildGLBrick(20,50,30); //upper band for another cup
		glTranslatef(-70,0,0);
		glTranslatef(0,25,0);
		buildGLBrick(140,10,20); //topmost connecting band
	glPopMatrix();
}

void buildRudementaryPerson ()
{
	
	glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(-50,25,0);
		buildGLCube(50); //start with the feet. Its right foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some design on that foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //more design for that foot
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(100,0,0); //equivalent to resetting, then going (30,25,-200)
		buildGLCube(50); //Its left foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some more design, this time for the left foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //still more design
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(-50, 150, 0); //for the torso: want x at 0 so 30-30, y at 150 so 25+75, z at same depth (for now)
		buildGLBrick(200,200,90); //the torso; should not be visible if clothes are on properly!
		glColor3f(0,1,0);
		buildGLBrick(200.1,100.01,95); //part of the shirt
		glColor3f(0.5,0.5,0.0);
		glTranslatef(0,-60,0);
		buildGLBrick(200.01,100.01,100); //part of the shorts
		glColor3f(0,0,0);
		glTranslatef(0,-40,0);
		buildGLBrick(10.01,50.01,102); //the crotch
		glTranslatef(0,100,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(-150,0,0); //put one arm out to the viewer's left by default
		buildGLBrick(40,50,40); //its right arm
		glTranslatef(300,0,0); //put the other arm out to the viewer's right by default
		buildGLBrick(40,50,40); //and its left arm
		glColor3f(0.5,0.5,0.5);
		glTranslatef(0,-60,0);
		buildGLBrick(60,100,5); //shell of the tablet
		glColor3f(0.4,0.4,0.4);
		buildGLBrick(55,90,5.1); //screen within the tablet
		glTranslatef(0,0,3);
		glScalef(0.5,0.5,0.5);
		buildFakeApple(); //Apple logo
		glScalef(2,2,2);
		glTranslatef(0,0,-3);
		glTranslatef(0,60,0);
		glTranslatef(-150,0,0);
		glTranslatef(0,50,0);
		glColor3f(0.5,0,0); //color of the T-shirt
		buildGLBrick(200.2,100,102); //T-shirt part: main body primary
		glTranslatef(0,10,0);
		buildGLBrick(280.2,65,95); //T-shirt part: main body shoulders
		glTranslatef(0,-10,0);
		glTranslatef(-150,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 1
		glTranslatef(300,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 2
		glTranslatef(-150,0,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(0,46,0);
		buildGLBrick(48,7,100.3); //the neck hole
		glTranslatef(0,90,0); //want the head just above the torso
		buildGLCube(100); //and the head
		glColor3f(.5,0,.5);
		buildHeadphones(); //throw on some headphones
	glPopMatrix();
}

void buildBystander (float * posX, float* posZ, float* angle)
{
	glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO);

	helperForPositionOfLegs += 1;
	int legChangeAfterNCycles = 40;
	if (helperForPositionOfLegs >= 2 * legChangeAfterNCycles)
	{
		helperForPositionOfLegs = 0;
	}
	glPushMatrix();
		checkPathing (posX, posZ, angle);
		if (helperForPositionOfLegs < legChangeAfterNCycles)
		{
			glColor3f(1,1,1);
			glTranslatef(-50,25,0);
			buildGLCube(50); //start with the feet. Its right foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some design on that foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //more design for that foot
			glTranslatef(0,0,-25.02);
			glColor3f(1,1,1);
			glTranslatef(100,0,10); //equivalent to resetting, then going (30,25,-200)
			buildGLCube(50); //Its left foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some more design, this time for the left foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //still more design
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
		}
		else if(helperForPositionOfLegs < 2*legChangeAfterNCycles)
		{
			glColor3f(1,1,1);
			glTranslatef(-50,25,10);
			buildGLCube(50); //start with the feet. Its right foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some design on that foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //more design for that foot
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
			glColor3f(1,1,1);
			glTranslatef(100,0,10); //equivalent to resetting, then going (30,25,-200)
			buildGLCube(50); //Its left foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some more design, this time for the left foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //still more design
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
		}
		glColor3f(1,1,1);
		glTranslatef(-50, 150, 0); //for the torso: want x at 0 so 30-30, y at 150 so 25+75, z at same depth (for now)
		buildGLBrick(200,200,90); //the torso; should not be visible if clothes are on properly!
		glColor3f(0,.2,.9);
		buildGLBrick(200.1,100.01,95); //part of the shirt
		glColor3f(0.5,0.5,0.0);
		glTranslatef(0,-60,0);
		buildGLBrick(200.01,100.01,100); //part of the shorts
		glColor3f(0,0,0);
		glTranslatef(0,-40,0);
		buildGLBrick(10.01,50.01,100.1); //the crotch
		glTranslatef(0,100,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(-150,0,0); //put one arm out to the viewer's left by default
		buildGLBrick(40,50,40); //its right arm
		glTranslatef(300,0,0); //put the other arm out to the viewer's right by default
		buildGLBrick(40,50,40); //and its left arm
		glColor3f(0.5,0.5,0.5);
		glTranslatef(0,-60,0);
		//buildGLBrick(60,100,5); //shell of the tablet
		//glColor3f(0.4,0.4,0.4);
		//buildGLBrick(55,90,5.1); //screen within the tablet
		glTranslatef(0,0,3);
		//glScalef(0.5,0.5,0.5);
		//buildFakeApple(); //Apple logo
		//glScalef(2,2,2);
		glTranslatef(0,0,-3);
		glTranslatef(0,60,0);
		glTranslatef(-150,0,0);
		glTranslatef(0,50,0);
		glColor3f(0.2,0,0); //color of the T-shirt
		buildGLBrick(200.2,100,102); //T-shirt part: main body primary
		glTranslatef(0,10,0);
		buildGLBrick(280.2,65,95); //T-shirt part: main body shoulders
		glTranslatef(0,-10,0);
		glTranslatef(-150,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 1
		glTranslatef(300,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 2
		glTranslatef(-150,0,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(0,46,0);
		buildGLBrick(48,7,100.3); //the neck hole
		glTranslatef(0,90,0); //want the head just above the torso
		buildGLCube(100); //and the head
		glColor3f(.5,.5,.5);
		buildHeadphones(); //throw on some headphones

	glPopMatrix();

	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void buildBlockyTree(int color)
{
	float sizeOfCubeyBranches = 50;
	float heightOfTrunk = 700;
	glColor3f((float)107.0/255.0,(float)69.0/255.0,0);

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleFine);
	buildGLBrick(45,heightOfTrunk,45); //actual trunk
	glDisable(GL_POLYGON_STIPPLE);

	glPushMatrix();

	if (color == PINK)
	{
		glColor3f((float)255/255.0,(float)176/255.0,(float)254/255.0);
	}
	else if (color == GREEN)
	{
		glColor3f((float)129/255.0,(float)255/255.0,(float)120/255.0);
	}
	else if (color == BLUE)
	{
		glColor3f((float)122/255.0,(float)204/255.0,(float)255/255.0);
	}
	else if (color == YELLOW)
	{
		glColor3f((float)255/255.0,(float)250/255.0,(float)110/255.0);
	}
	else
	{
		glColor3f(0.5,0.5,0.5);
	}
	glTranslatef(0,.5*heightOfTrunk,0);

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleFine);
	buildGLCube(.35*heightOfTrunk);
	glDisable(GL_POLYGON_STIPPLE);


	glTranslatef(60,.5*sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(-120,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,60);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,-120);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(120,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(-60,sizeOfCubeyBranches,60);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);

	glPopMatrix();
}

void buildCloudyCloud(int color, float thickness, float alpha)
{
	int quality = 10;
	if (color == PINK)
	{
		glColor4f((float)255/255.0,(float)176/255.0,(float)254/255.0,alpha);
	}
	else if (color == GREEN)
	{
		glColor4f((float)129/255.0,(float)255/255.0,(float)120/255.0,alpha);
	}
	else if (color == BLUE)
	{
		glColor4f((float)122/255.0,(float)204/255.0,(float)255/255.0,alpha);
	}
	else if (color == YELLOW)
	{
		glColor4f((float)255/255.0,(float)250/255.0,(float)110/255.0,alpha);
	}
	else
	{
		glColor4f(0.5,0.5,0.5,alpha);
	}
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	gluSphere(quadric, thickness, quality,quality);

	glPushMatrix();
		glTranslatef(-thickness,.5*thickness,0);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(thickness,.5*thickness,0);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(1.5*thickness,0,.25*thickness);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-1.5*thickness,0,.25*thickness);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();
}

void buildFakeTundra() //this is the test plane, aka fake tundra, drawn beneath the person to verify movement in the proper direction
{
	float halfSizeOfTundra = 4000;
	glBegin(GL_POLYGON);
		glColor3f((float)44.0/255.0,(float)135.0/255.0,0);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		//glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		//glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		//glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,0,0,1);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,0,0,-1);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,1,0,0);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,-1,0,0);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
		glTranslatef(600,300,1000);
		buildBlockyTree(PINK);
	glPopMatrix();
	
	glPushMatrix();
		glTranslatef(900,300,650);
		buildBlockyTree(BLUE);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(900,300,1800);
		buildBlockyTree(GREEN);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(400,300,800);
		buildBlockyTree(YELLOW);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-1400,300,-450);
		buildBlockyTree(BLUE);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-1000, 300, -1600);
		buildBlockyTree(PINK);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(1550, 300, -800);
		buildBlockyTree(OTHER);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-150, 300, 1500);
		buildBlockyTree(BLUE);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(1600, 300, -700);
		buildBlockyTree(OTHER);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-900, 300, 1200);
		buildBlockyTree(YELLOW);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(1400, 300, 1800);
		buildBlockyTree(OTHER);
	glPopMatrix();
}

void myinit()
{
 	glClearColor((float)79.0/255.0, (float)185.0/255.0, (float)255.0/255.0, 1.0); /*blue background */
      
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(currentFieldOfViewY, 1, 0.1, 4000); //sorta defines how much of the world we can roam

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//change lookat (center) Y back to 0 if broken
	gluLookAt(-1000*sin((thetaToRotatePerson * PI / 180.0)) + currentXCoordinate, 96, 0 - 1000*cos((thetaToRotatePerson * PI / 180.0)) + currentZCoordinate, /* from where do you want to look? aka the camera XYZ */
		-500*sin((thetaToRotatePerson * PI / 180.0)) + currentXCoordinate, 100, 0 - 500*cos((thetaToRotatePerson * PI / 180.0)) + currentZCoordinate, /* where is the thing you want to see? use an X, Y, and Z! */
			0, 1, 0); /* desired normal vector, with the origin as your imaginary start and this XYZ as the end/the direction. */


	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
}

void buildCloudCollection()
{
	int colorPositionCount = 1;
	for (float xTrans = -2000; xTrans < 2001; xTrans= xTrans+400)
	{
		for (float zTrans = -2000; zTrans < 2001; zTrans = zTrans+400)
		{
		glPushMatrix();
			glTranslatef(xTrans*1.5,0,zTrans*1.5);
			switch(colorPositionCount) {
			case PINK:
				buildCloudyCloud(PINK,(float)70,(float)0.5);
				colorPositionCount++;
				break;
			case GREEN:
				buildCloudyCloud(GREEN,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case BLUE:
				buildCloudyCloud(BLUE,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case YELLOW:
				buildCloudyCloud(YELLOW,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case OTHER:
				buildCloudyCloud(OTHER,(float)70,(float)0.3);
				colorPositionCount = PINK;
				break;
			}
		glPopMatrix();
		}
	}
}

void display( void )
{
	
	myinit(); //this is the typical init function, but it also holds the camera config info

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  /*clear the window */
	//END SETUP; BEGIN DRAWING THINGS
	
	buildFakeLogo(100); //this acts as our initial positioning system

	//fake sun high in the sky, plus some clouds
	glPushMatrix();
		glTranslatef(-780,1400+900,-3000);
		makeASun(350); //build the actual sun
		glTranslatef(0,-900,3000);
		
		
		buildCloudCollection();
	glPopMatrix();

	//build fake tundra, with built-in fake trees that look like roman candles
	buildFakeTundra();

	//and the person
	glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
			glTranslatef(currentXCoordinate,30,currentZCoordinate);
			glRotatef(thetaMultiplier * thetaToRotatePerson,0,1,0);
			glScalef(currentScalingMagnitude,currentScalingMagnitude,currentScalingMagnitude);
			buildRudementaryPerson();
	glPopMatrix(); //...restore the state of the matrix after the person is called!

	//and since order matters for transparency, the student center
	buildBlockyStudentCenter();

	//plus some random bystanders who do nothing on their own.
	//right now, they walk around whenever you move/rotate the person, and they follow a box (affected by the pathing function)
	glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
		glTranslatef(bystanderAPosX,15,bystanderAPosZ);
		glRotatef(bystanderAngleA,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderAPosX, &bystanderAPosZ, &bystanderAngleA);
	glPopMatrix();
	glPushMatrix();
		glTranslatef(bystanderBPosX,15,bystanderBPosZ);
		glRotatef(bystanderAngleB,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderBPosX, &bystanderBPosZ, &bystanderAngleB);
	glPopMatrix(); 
	glPushMatrix();
		glTranslatef(bystanderCPosX,15,bystanderCPosZ);
		glRotatef(bystanderAngleC,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderCPosX, &bystanderCPosZ, &bystanderAngleC);
	glPopMatrix(); //...restore the state of the matrix after each person is made!
	

	//have a butterfly
	glPushMatrix();
		checkPathingButterfly(&butterflyAPosX,&butterflyAPosY,&butterflyAPosZ,&butterflyAZig);
		glTranslatef(butterflyAPosX,butterflyAPosY+250,butterflyAPosZ);
		//glScalef(100,100,100);
		butterfly();
	glPopMatrix();

	glPushMatrix();
		checkPathingButterfly(&butterflyBPosX,&butterflyBPosY,&butterflyBPosZ,&butterflyBZig);
		glTranslatef(butterflyBPosX,butterflyBPosY+250,butterflyBPosZ);
		butterfly();
	glPopMatrix();

	glPushMatrix();
		checkPathingButterfly(&butterflyCPosX,&butterflyCPosY,&butterflyCPosZ,&butterflyCZig);
		glTranslatef(butterflyCPosX,butterflyCPosY+250,butterflyCPosZ);
		butterfly();
	glPopMatrix();

	glutSwapBuffers();
 }


// This function is called whenever the window size is changed
// OpenGL, in tandem with the OS, decide what to do, and provide the necessary params.
//@params: the new width and height of the display window, to assist with how to scale accordingly
//@return: [none]
void manageReshape (int w, int h)
{
	if (w < h)
	{
		glViewport (0, ((h - w) /2), (GLsizei) w, (GLsizei) w); // Set the viewport
	}
	else if (h < w)
	{
		glViewport (((w - h) /2), 0, (GLsizei) h, (GLsizei) h); // Set the viewport
	}
	else
	{
		glViewport (0, 0, (GLsizei) w, (GLsizei) h); // Set the viewport
	}
}

//called on normal key presses--for now, 0, 1
void manageNormalKeyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
		case '0' :
			currentScalingMagnitude += scaleChangeMagnitude;
		break;

		case '1' :
			if (currentScalingMagnitude - scaleChangeMagnitude <= 0)
			{
				currentScalingMagnitude = currentScalingMagnitude;
			}
			else
			{
				currentScalingMagnitude -= scaleChangeMagnitude;
			}
		break;

		case '7' :
			if ((currentFieldOfViewY - fieldOfViewDelta) < 1 || (currentFieldOfViewY - fieldOfViewDelta) < (originalFieldOfViewY - 40))
			{
				currentFieldOfViewY = currentFieldOfViewY;
			}
			else
			{
				currentFieldOfViewY -= fieldOfViewDelta;
			}
		break;

		case '8' :
			if ((currentFieldOfViewY - fieldOfViewDelta) > 179 || (currentFieldOfViewY - fieldOfViewDelta) > (originalFieldOfViewY + 40))
			{
				currentFieldOfViewY = currentFieldOfViewY;
			}
			else
			{
				currentFieldOfViewY += fieldOfViewDelta;
			}
		break;
		case '4':
			for (int i = 0; i < 100; i++)
			{
				display();
			}
			break;
		case '5':
			glutPostRedisplay();
			break;
	}
	glutPostRedisplay(); // Redraw the scene

}

// called on special key pressed
void manageArrowKeyInput(int key, int x, int y) { 

	// Check which key is pressed
	float temporaryThetaForMinus = thetaToRotatePerson; //variable used to help restrict values returned by sin and cos functions used to provide movement; see individual uses.
	float temporaryThetaForPlus = thetaToRotatePerson; //variable used to help restrict values returned by sin and cos functions used to provide movement; see individual uses.
	float forward_back_Multiplier = 16.0f;
	switch(key) {
		case GLUT_KEY_LEFT: // Rotate counterclockwise, and determine the direction & magnitude at which you would move once rotated.
			thetaToRotatePerson += thetaChangeMagnitude;
			while (temporaryThetaForPlus >= 360) //this will prevent the sin and cos functions from dealing with a theta value greater than 360 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				temporaryThetaForPlus -= 360;
			}
			runX = cosf(temporaryThetaForPlus * PI / 180);
			riseY = sinf(temporaryThetaForPlus * PI / 180);
		break;
		case GLUT_KEY_RIGHT: // Rotate clockwise, and determine the direction & magnitude at which you would move once rotated.
			thetaToRotatePerson -= thetaChangeMagnitude;
			while (temporaryThetaForMinus < 0)  //this will prevent the sin and cos functions from dealing with a theta value less than 0 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				temporaryThetaForMinus += 360;
			}
			runX = cosf(temporaryThetaForMinus * PI / 180);
			riseY = sinf(temporaryThetaForMinus * PI / 180);
		break;
		case GLUT_KEY_UP : // Move in the forward direction relative to the current view, based on rise and run values determined above
			currentXCoordinate += forward_back_Multiplier * riseY;
			currentZCoordinate += forward_back_Multiplier * runX;
		break;
		case GLUT_KEY_DOWN : // Move in the reverse direction relative to the current view, based on rise and run values determined above
			currentXCoordinate -= forward_back_Multiplier * riseY;
			currentZCoordinate -= forward_back_Multiplier * runX;
		break; 
	}

    glutPostRedisplay(); // Redraw the scene
}







void main(int argc, char** argv)
{

/* Standard GLUT initialization */

    glutInit(&argc,argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); /*as set by default*/
    glutInitWindowSize(800,800); /* 500 x 500 window by default*/
    glutInitWindowPosition(0,0); /* place window top left on display */
    glutCreateWindow("COMP-5/6400 Assignment 4"); /* window title */
	
	glutReshapeFunc(manageReshape); //defines what method to call when the user resizes a window; target function is defined above
	glutKeyboardFunc(manageNormalKeyInput);
	glutSpecialFunc(manageArrowKeyInput); //tells the program to be waiting for input from arrow keys; target function is defined above
    glutDisplayFunc(display); /* display callback invoked when window opened */
	glEnable(GL_DEPTH_TEST);
	//glDepthFunc(GL_LESS);
	glDepthFunc(GL_ALWAYS);
	glShadeModel(GL_SMOOTH);

	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glutMainLoop(); /* enter event loop */
}
