
/*Auburn University Student Center, plus mobile person. */
/*	COMP5400 Assignment #06 ver AA, from Assn 05 ver BA */
/*Albert Wallace, aew0024, 10 April 2014 */
/*outside code assistance, if required, noted in the code itself*/


//have the sun set, and the moon come out, and the light automatically just get darker as you desire.

/********************************************************************************
 *TO CONTROL the digital person (D.P.), these USER CONTROLS are available:
 ********************************************************************************/
/*
---0 key increases D.P.'s size, 1 key decreases D.P.'s size (minimum size is default, maximum is undefined and he WILL begin to disappear once he grows too big)
---8 key increases the field of view in the Y direction, 7 key decreases the field of view (zooms out and in, respectively)
---Left and right arrow keys rotate D.P. as if the feet were on a spinning platform
---		(the camera remains with D.P., always looking at his back so you can see ahead)
---Up and Down arrow keys result in moving forward or backward, respectively, relative to camera position
---4 key renders animation for 100 cycles then stops (allegedly). 5 key, when held down, forces animation.
---"l" [lowercase or uppercase] key cycles through various lighting modes:
---     -Mode 1 is a front-facing white spotlight, with a yellow sun. [FLASHLIGHT MODE]
---     -Mode 2 is multiple front-facing spotlights of red and blue, with spotlights shining down, and a blue sun. [CUPID MODE]
---     -Mode 3 combines Mode 2 with Mode 1, with effects of Mode 1 taking preference over effects of Mode 2 where necessary. [FLASHLIGHT + CUPID MODE]
---     -Mode 4 turns off all separate lights, including the sun, but leaves global ambient lighting enabled. ["THE DARKNESS" MODE]
---"+" [plus] key increases light intensity of global ambient lighting and the white spotlight in mode 1 and mode 3. "-" [minus] key decreases the light in a similar fashion.

***NEW CONTROLS AVAILABLE FOR ASSIGNMENT 6!***
---"F" or "f" toggles fly-free mode, where the camera is bound to the person [normal], or the camera is free from the person [free-fly]. Tour mode is still supported either way.
---"A"/"a" will toggle auto-tour on/off for D.P. [or the camera, depending on whether we are in free fly mode or not];
		note that this will result in the tour immediately running, but will not run indefinitely. Use "R" and "B" below for more control of the tour.
	"R"/"r" will attempt to run the auto-path mode (bystanders/butterflies) & auto-tour mode (for the camera or student) 
		if it automatically pauses or is manually paused. This does not result in indefinite runs.
	"B"/"b" will attempt to pause the auto-path mode while in the middle of a run. Opposite of "R".
---"PAGEDOWN" rotates the camera so it looks down (freefly or while controlling D.P.)
---"PAGEUP" rotates the camera so it looks up (freefly or while controlling D.P.)
---"SPACE + UP ARROW" allows you to rise up (straight up) either as D.P. or in free-fly mode
---"SPACE + DOWN ARROW" allows you to drop down (straight down) either as D.P. or in free-fly mode
---		-flying up and over the building or other blocked objects allows you to touch down in regions
---			previously unavailable to you. You can't really walk around in them, but you can fly back out again.
---"C" or "c" enable/disable COUCH MODE. Try it. Self-explanatory.
---"D" or "d" allow you to override collision detection and still move freely. [The sky will glow green while enabled].
---		The next move after re-enabling collision detection will return you to the last known good position.
---As always, see "OTHER COMMENTS" below.
*/

//############# OTHER COMMENTS: ######################################
/**
***NEW FOR ASSIGNMENT 6!***
---Things may or may not automatically move upon program startup. This is normal and expected.
---2+ key combinations may not be supported on every system. In that case, SPACE + UP ARROW or SPACE + DOWN ARROW may not work.
---You are still allowed to walk off the edge of the earth & shoot straight up indefinitely.
		It's your own fault if you fly too close to the sun, Icarus.
---Collision detection is a little offset from the building itself. This invisible force field is by design.
--- Collision detection is a bit iffy around the trees. Have fun with that. You may run into a tree; you may not.
--- You can still walk through other people and the butterflies.
--- The automatic paths may still take you through the building. That's fine.
---The sky MAY turn red if you trigger collision detection. You've been warned.
*/
//D.P. walks around on the XZ plane, with the positive Y axis representing the normal vector for the entire visible world. 
//   ...If he gets too big, he may sink. If he gets too small, he may float. He is made of magic. 
//   ...(Scaling doesn't take into account the translation needed to get him to the right position by default).
//Butterflies never change their body rotation, so they will appear to fly sideways about half of the time.
//The bodies of the people are somewhat transparent/glitchy. No attempts were made to fix them, as they are unimportant.
//The wings of the butterflies have nothing in them. This is a known fact, and is accepted as a new breed of butterfly.
//The pathing functions will send the people and the butterflies through the student center. This is accepted, as they are ghosts.
//People and butterflies will only move when you move D.P. (or press the unassigned button listed above), including when you modify his rotation and scaling. Every button press drives them in their animation.
//   ...For the remainder of the time, they are frozen in position. They are time lords, and you should not even be seeing them.
//You are allowed to walk through the building, you are allowed to walk off the edge of the world, and you are allowed to walk through people.
//   ...It's not your magic; I just like the effect.
//You can never view D.P.'s face by default. There is no mirror, and there is no way to detach the camera from the rear view.
//   ...This is by design, and makes the focus be on his abilities rather than on his appearance.
//   ...(But the appearance of the other people very much matters, as is the case in life. That's why they look wonky.)
//All other unmarked glitches are, in fact, glitches, but were left in with the knowledge that perfection is difficult to attain.


//Unnecessary header files now no longer included.
//Use of sqrt function changes after exclusion of previously included header files, due to multiple overloaded versions. Fix now implemented.

#include <stdlib.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <math.h>

#define PI 3.141592653589739

//colors for trees
const int PINK = 1;
const int GREEN = 2;
const int BLUE = 3;
const int YELLOW = 4;
const int OTHER = 5;

//more variables
float sbr = 2; //LEGACY; ratio by which to scale select values; unused in newer code, soon to be deprecated
float denomRGB = 255; //to convert from 8-bit representation to float representation
float thetaChangeMagnitude = 2.5f; //used to decide how much a person rotates, in degrees, upon each arrow press
float thetaToRotatePerson = 180.0f;
float currentXCoordinate = 0.0f; //current X coordinate of the center of the face and camera; original value defines the starting point
float currentZCoordinate = 550.0f; //current Z coordinate of the center of the face and camera; original value defines the starting point
float thetaMultiplier = 1.000f; //can be used to speed up or slow down the rotation of the man relative to the camera
float scaleChangeMagnitude = 0.2f; //additive value, helping to control the act of shrinking or growing D.P. with the keyboard keys defined above for scaling up and down; affects the scaling value which itself is multiplicative
float currentScalingMagnitude = 0.5f; //the value ultimately affected by the scaleChangeMagnitude during user input, used to scale D.P. up or down. Should never be zero.
float riseY = 0.0f; //dictates how far to move along the appropriate axis (not the Y axis...refer to each individual use! Expect it to affect the X axis.), whether positive or negative; original value defines initial movement with up & down arrows
float runX = -2.0f; //dictates how far to move along the appropriate axis (not the X axis...refer to each individual use! Excpect it to affect the Z axis.), whether positive or negative; original value defines initial movement with up & down arrows
float originalFieldOfViewY = 75.0f; //defines the initial config for the field of view; defines the min/max
float currentFieldOfViewY = originalFieldOfViewY; //the current setting for the field of view
float fieldOfViewDelta = 2.0f; //defines the increment or decrement steps when using keys 7/8
float thetaForTrig = thetaToRotatePerson; //same value as thetaToRotatePerson, just bounded to between 0 and 360, 0-inclusive and 360-exclusive

//variables related to lighting
int glLightEnableInStep = 0;
float generalLightMagnitude = 0.7;
float lightMagDelta = 0.1;


//values for animation of random people
int helperForPositionOfLegs = 0;
float pathingLengthHalved = 2500; //half of the desired travel of one bystander along a given axis (X or Z) (bystanders travel along a box-like path)
float bystanderAPosX = 0, bystanderAPosZ = pathingLengthHalved + 2, bystanderBPosX = 150, bystanderBPosZ = pathingLengthHalved+ 2, bystanderCPosX = 450, bystanderCPosZ = pathingLengthHalved + 2;
float bystanderAngleA = 90, bystanderAngleB = 90, bystanderAngleC = 90;

//and for the butterflies
bool wingReverse = false;
float flapDegrees = 0;
float butterflyAPosX = -600, butterflyAPosY = 0, butterflyAPosZ = pathingLengthHalved + 2, butterflyBPosX = -150, butterflyBPosY = 0, butterflyBPosZ = pathingLengthHalved+ 2, butterflyCPosX = -450, butterflyCPosY = 0, butterflyCPosZ = pathingLengthHalved + 2;
bool butterflyAZig = false, butterflyBZig = true, butterflyCZig = false;

//collision detection: where to not collide
bool detectCollisionAreas = true; //set to false after initial run to prevent calculations from being done again
const int maxNumberOfTrees = 20; //maximum number of trees to be 'counted' during collision detection
	//storage for the mins and maxs for the trees made during the buildFakeTundra method
int treesMinX[maxNumberOfTrees];
int treesMaxX[maxNumberOfTrees];
int treesMinZ[maxNumberOfTrees];
int treesMaxZ[maxNumberOfTrees];
bool treeInSlot[maxNumberOfTrees]; //indicate whether the tree is to be counted during collision detection or not (TRUE = counts for collision; FALSE = can phase through).
//for the person
bool returnToLastPosition = true;
float oldXCoordinate = currentXCoordinate, oldZCoordinate = currentZCoordinate;
float oldXCoordPthng = currentXCoordinate, oldZCoordPthng = currentZCoordinate, oldRotateAngle = thetaToRotatePerson;
bool gotLastPosition = false;

//attempt to try keyboard interrupt
bool keyInputIRQ = false; //if ever set true, interrupt redraw; else, don't
bool personAutoMove = false;
bool modifierKey = false; //used to detect if you press space + something else
float translateYVal = 0;
float defaultTranslateYVal = translateYVal;

//allow the camera to fly free of the student, and put the student high in the sky
bool flyFreeFly = false;
float cameraRotateUpDownTheta = 0; //variable used to tilt the camera up or down
bool flashRed = false; //used to make the sky flash red if you trigger collision detection
bool renderCouchInsteadOfPerson = false; //used to trigger COUCH MODE[tm]
bool ignoreCollisionDetection = false; //used to allow the user to override collision detection
float overrideXCoord = currentXCoordinate;
float overrideZCoord = currentZCoordinate;

GLubyte stippleStyleFine[] = {
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0x55, 0x55, 0x55, 0x55,/* 01....01 01....01 01....01 01....01*/ 
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA,/* 10....10 10....10 10....10 10....10*/
0xAA, 0xAA, 0xAA, 0xAA /* 10....10 10....10 10....10 10....10*/
}; //GLubyte stippleStyleFine[]

GLubyte stippleStyleStripe[] = {
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0xFF, 0xFF, 0xFF, 0x55,/* 11111111 11111111 11111111 01....01*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
0x55, 0xFF, 0xFF, 0xFF,/* 01....01 11111111 11111111 11111111*/ 
}; //GLubyte stippleStyleStripe[]

GLubyte stippleStyleBrick[] = {
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0xFF, 0x55, 0xFF, 0x55,/* 11111111 01....01 11111111 01....01*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/ 
0x55, 0xFF, 0x55, 0xFF,/* 01....01 11111111 01....01 11111111*/  
}; //GLubyte stippleStyleBrick[]


//the following method for calculating normals found on Microsoft's website at the following link: http://support.microsoft.com/kb/131130
inline GLvoid getNormal(GLfloat fVert1X, GLfloat fVert1Y, GLfloat fVert1Z, 
							 GLfloat fVert2X, GLfloat fVert2Y, GLfloat fVert2Z, 
                             GLfloat fVert3X, GLfloat fVert3Y, GLfloat fVert3Z, 
							 GLfloat *fNormalX, GLfloat *fNormalY, GLfloat *fNormalZ)
    {
    GLfloat Qx, Qy, Qz, Px, Py, Pz;

   Qx = fVert2X-fVert1X;
   Qy = fVert2Y-fVert1Y;
   Qz = fVert2Z-fVert1Z;
   Px = fVert3X-fVert1X;
   Py = fVert3Y-fVert1Y;
   Pz = fVert3Z-fVert1Z;

   *fNormalX = Py*Qz - Pz*Qy;
   *fNormalY = Pz*Qx - Px*Qz;
   *fNormalZ = Px*Qy - Py*Qx;

   }


inline GLvoid setNormal(GLfloat fVert1X, GLfloat fVert1Y, GLfloat fVert1Z, 
				GLfloat fVert2X, GLfloat fVert2Y, GLfloat fVert2Z, 
                GLfloat fVert3X, GLfloat fVert3Y, GLfloat fVert3Z)
{
	GLfloat normalX, normalY, normalZ;
	getNormal(fVert1X, fVert1Y, fVert1Z, fVert2X, fVert2Y, fVert2Z, fVert3X, fVert3Y, fVert3Z, &normalX, &normalY, &normalZ);
	glNormal3f(normalX, normalY, normalZ);
}

void buildGLRectangle(float xMin, float xMax, float yMin, float yMax) //used to speed up the creation of a GL QUAD that will only be a rectangle or square
{
	glBegin(GL_QUADS); 
		glVertex2f(xMin*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMax*sbr);
		glVertex2f(xMin*sbr,yMax*sbr);
	glEnd();
}

void buildGLRectangleH(float xMin, float xMax, float zMin, float zMax) //used to speed up the creation of a GL QUAD that will only be a rectangle or square
{
	glBegin(GL_QUADS); 
		glVertex3f(xMin*sbr,0,zMin*sbr);
		glVertex3f(xMax*sbr,0,zMin*sbr);
		glVertex3f(xMax*sbr,0,zMax*sbr);
		glVertex3f(xMin*sbr,0,zMax*sbr);
	glEnd();
}

void makeASun(float radius)

{
	if (glLightEnableInStep == 1)
	{
		glColor3f(1,1,1);
	}
	else
	{
		glColor3f((float)255.0/255.0,(float)211.0/255.0,(float)79.0/255.0);
	}
	int qualityA = 100, qualityAB = 90, qualityB = 80, qualityC = 70, qualityD = 60, qualityF = 40;
	int quality = qualityD;
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	gluSphere(quadric, radius, quality,quality);
}


void surfbort() //the easter egg code which prints the word "surfbort" on a banner. Can be treated as an entire object, like the build... functions below.
{
	glColor3f(.1,.1,.1);
	buildGLRectangle(-200,200,-50,50);
	glColor3f(1,1,1);
	glBegin(GL_LINE_STRIP);
		glVertex3f(-175,45,0.1);
		glVertex3f(-195,45,0.1);
		glVertex3f(-195,3,0.1);
		glVertex3f(-175,3,0.1);
		glVertex3f(-175,-40,0.1);
		glVertex3f(-195,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-160,45,0.1);
		glVertex3f(-160,-40,0.1);
		glVertex3f(-135,-40,0.1);
		glVertex3f(-135,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-120,-40,0.1);
		glVertex3f(-120,45,0.1);
		glVertex3f(-90,45,0.1);
		glVertex3f(-90,2,0.1);
		glVertex3f(-120,2,0.1);
		glVertex3f(-90,-40,0.1);
	glEnd();
	
	glBegin(GL_LINE_STRIP);
		glVertex3f(-80,-40,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-40,45,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-80,2,0.1);
		glVertex3f(-45,2,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-35,45,0.1);
		glVertex3f(-35,-40,0.1);
		glVertex3f(-5,-40,0.1);
		glVertex3f(-35,2,0.1);
		glVertex3f(-5,2,0.1);
		glVertex3f(-5,45,0.1);
		glVertex3f(-35,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(0,45,0.1);
		glVertex3f(0,-40,0.1);
		glVertex3f(30,-40,0.1);
		glVertex3f(30,45,0.1);
		glVertex3f(0,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(40,-40,0.1);
		glVertex3f(40,45,0.1);
		glVertex3f(70,45,0.1);
		glVertex3f(70,2,0.1);
		glVertex3f(40,2,0.1);
		glVertex3f(70,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(80,45,0.1);
		glVertex3f(110,45,0.1);
		glVertex3f(95,45,0.1);
		glVertex3f(95,-40,0.1);
	glEnd();
	
}

void buildFakeLogo(float lengthOfSides) //this is the test cube, aka the logo, that happens to be shown in the lower left
{
	//face one -- parallel to XY plane, positive
	glColor3f(1,1,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	glColor3f(0,0.40,0);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face four --parallel to YZ plane, negative
	glColor3f(0,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	glColor3f(0.80,0.80,0);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}


void buildGLCubeRR(float lengthOfSides)
{

	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		//setNormal(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		setNormal(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		
		setNormal(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);

	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		setNormal(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		//setNormal(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}

void buildGLBrick(float width, float height, float depth)
{
	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		setNormal(0.5*width,0.5*height,0.5*depth,-0.5*width,0.5*height,0.5*depth,-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		//setNormal(-0.5*width,0.5*height,0.5*depth,-0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		//setNormal(-0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		//setNormal(0.5*width,-0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth,-0.5*width,0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		setNormal(0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		//setNormal(-0.5*width,0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth,0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		//setNormal(-0.5*width,-0.5*height,-0.5*depth,0.5*width,-0.5*height,-0.5*depth,0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		//setNormal(0.5*width,-0.5*height,-0.5*depth,0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		setNormal(0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,-0.5*depth,0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		//setNormal(0.5*width,0.5*height,-0.5*depth,0.5*width,-0.5*height,-0.5*depth,0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		//setNormal(0.5*width,-0.5*height,-0.5*depth,0.5*width,-0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		//setNormal(0.5*width,-0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		setNormal(-0.5*width,0.5*height,0.5*depth,-0.5*width,0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		//setNormal(-0.5*width,0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		//setNormal(-0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,0.5*depth,-0.5*width,0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		//setNormal(-0.5*width,-0.5*height,0.5*depth,-0.5*width,0.5*height,0.5*depth,-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		setNormal(0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		//setNormal(0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,0.5*depth);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		//setNormal(-0.5*width,0.5*height,-0.5*depth,-0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		//setNormal(-0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,0.5*depth,0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		setNormal(0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		//setNormal(0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		//setNormal(-0.5*width,-0.5*height,-0.5*depth,-0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		//setNormal(-0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,0.5*depth,0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
	glEnd();
}

inline void buildGLCube(float lengthOfSides)
{
	int divisionsToMake = 2;
	glPushMatrix();
	glTranslatef((-lengthOfSides/2),(-lengthOfSides/2),(-lengthOfSides/2));
	glTranslatef((lengthOfSides/divisionsToMake)/2,(lengthOfSides/divisionsToMake)/2,(lengthOfSides/divisionsToMake)/2);
	for (int i = 0; i < lengthOfSides; i+=(lengthOfSides/divisionsToMake))
	{
		for (int j = 0; j < lengthOfSides; j+=(lengthOfSides/divisionsToMake))
		{
			for (int k = 0; k < lengthOfSides; k+=(lengthOfSides/divisionsToMake))
			{
				glPushMatrix();
					glTranslatef(i,j,k);
					buildGLCubeRR(lengthOfSides/divisionsToMake);
				glPopMatrix();
			}
		}
	}
	glPopMatrix();
}

void buildCouch()
{
	glPushMatrix();
		glTranslatef(0,150,0);
		glTranslatef(0,0,-125);
		buildGLBrick(600,300,50); //back of couch
		glTranslatef(0,-90,250);
		buildGLBrick(600,120,50); //front of couch
		glTranslatef(0,60,-125);
		buildGLBrick(600,50,350); //seat of couch
		glTranslatef(275,-60,0);
		buildGLBrick(50,125,225);
		glTranslatef(-575,0,0);
		buildGLBrick(50,125,225);
	glPopMatrix();
}

void buildEquilateralTriangle(float lengthOfSide)
{
	glBegin(GL_TRIANGLES);
		glVertex3f(0,0,0);
		glVertex3f(-0.5*lengthOfSide,-.5*lengthOfSide*sqrt((float)3.0),0);
		glVertex3f(0.5*lengthOfSide,-.5*lengthOfSide*sqrt((float)3.0),0);
	glEnd();
}

void resumeManualStudentCtrl(float * personXPosition, float * personZPosition, float * personAngle)
{
	if (returnToLastPosition)
	{
		*personXPosition = oldXCoordPthng;
		*personZPosition = oldZCoordPthng;
		*personAngle = oldRotateAngle;
		gotLastPosition = false;
	}
}

void automatedStudentPathing(float * personXPosition, float * personZPosition, float * personAngle)
{
	if (!gotLastPosition)
	{
		oldXCoordPthng = *personXPosition;
		oldZCoordPthng = *personZPosition;
		oldRotateAngle = *personAngle;
		gotLastPosition = true;
		*personXPosition = -1 * (pathingLengthHalved + 2);
	}

	float changePositionParamsBy = 10; //by how much to move each person along its respective axis
	if (*personXPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 0;
		*personZPosition += changePositionParamsBy;
	}
	if (*personZPosition > pathingLengthHalved + 1)
	{
		*personAngle = 90;
		*personXPosition += changePositionParamsBy;
	}
	if (*personXPosition > pathingLengthHalved + 1)
	{
		*personAngle = 180;
		*personZPosition -= changePositionParamsBy;
	}
	if (*personZPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 270;
		*personXPosition -= changePositionParamsBy;
	}
	if (*personAngle >= (float)360)
		*personAngle = (float)0;
}

//return whether it is safe for the person to move, based on rough collision detection algorithm
bool checkPrimaryStudentCollisionCoordinates(float xPos, float zPos)
{
	//these student center variables calculated from the OpenGL translations & 
	//		custom cube-building calls done in buildBlockyStudentCenter method
	int minX_SS = -570;
	int maxX_SS = 920;
	int minZ_SS = -2900;
	int maxZ_SS = 160;
	bool shouldNotMove = false;

	if (translateYVal > 1000)
	{
		flashRed = false;
		return !shouldNotMove;
	}

	if (zPos > minZ_SS && zPos < maxZ_SS)
	{
		if (xPos > minX_SS && xPos < maxX_SS)
		{
			flashRed = true;
			return shouldNotMove;
		}
	}

	for (int treeToCheck = 0; treeToCheck < maxNumberOfTrees; treeToCheck++)
	{
		if (treeInSlot[treeToCheck])
		{
			if (xPos > treesMinX[treeToCheck] && xPos < treesMaxX[treeToCheck])
			{
				if (zPos > treesMinZ[treeToCheck] && zPos < treesMaxZ[treeToCheck])
				{
					flashRed = true;
					return shouldNotMove;
				}
			}
		}
		
	}
	flashRed = false;
	return !shouldNotMove;

}

//directly determines the next position for the bystander students
void automatedBystanderPathing(float * personXPosition, float * personZPosition, float * personAngle)
{
	float changePositionParamsBy = 10; //by how much to move each person along its respective axis
	if (*personXPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 0;
		*personZPosition += changePositionParamsBy;
	}
	if (*personZPosition > pathingLengthHalved + 1)
	{
		*personAngle = 90;
		*personXPosition += changePositionParamsBy;
	}
	if (*personXPosition > pathingLengthHalved + 1)
	{
		*personAngle = 180;
		*personZPosition -= changePositionParamsBy;
	}
	if (*personZPosition < -1 * (pathingLengthHalved + 1))
	{
		*personAngle = 270;
		*personXPosition -= changePositionParamsBy;
	}
	if (*personAngle >= (float)360)
		*personAngle = (float)0;
}

//directly determines the next position for the butterflies or birds
void automatedButterflyPathing(float * butterflyX, float * butterflyY, float * butterflyZ, bool * zigNotZag)
{
	float changeinY = 1;
	float maxHeightOfFlight = 100;

	
	float changePositionParamsBy = 10; //by how much to move each person along its respective axis
	//float pathingLengthHalved = 1700;

	if (*butterflyX < -1 * (pathingLengthHalved + 1))
	{
		*butterflyZ += changePositionParamsBy;
	}
	if (*butterflyZ > pathingLengthHalved + 1)
	{
		*butterflyX += changePositionParamsBy;
	}
	if (*butterflyX > pathingLengthHalved + 1)
	{
		*butterflyZ -= changePositionParamsBy;
	}
	if (*butterflyZ < -1 * (pathingLengthHalved + 1))
	{
		*butterflyX -= changePositionParamsBy;
	}
	if (*zigNotZag)
	{
		*butterflyY += 2*changeinY;
		if (*butterflyY > maxHeightOfFlight)
		{
			*zigNotZag = false;
		}
	}
	else if (!*zigNotZag)
	{
		*butterflyY -= changeinY;
		if (*butterflyY < -maxHeightOfFlight)
		{
			*zigNotZag = true;
		}
	}
}

void butterfly()
{
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	double radiusOfWing = 50;
	double thicknessOfWing = 10;
	int wingQuality = 20;
	
	glColor4f(0,0,(float)0.5,1); //this is the nice shade of blue

	//the wings of the butterfly
	if (wingReverse)
	{
		flapDegrees -= 2.0;
		if (flapDegrees < -75)
		{
			flapDegrees = -75;
			wingReverse = false;
		}
	}
	else if (!wingReverse)
	{
		flapDegrees += 1.0;
		if (flapDegrees > 75)
		{
			flapDegrees = 75;
			wingReverse = true;
		}
	}

	//glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleStripe);
	glPushMatrix();
		glRotatef(flapDegrees,0,0,1);
		glTranslatef(radiusOfWing,0,0);
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfWing, radiusOfWing, thicknessOfWing, wingQuality, wingQuality);
	glPopMatrix();
	glPushMatrix();
		glRotatef(-flapDegrees,0,0,1);
		glTranslatef(-radiusOfWing,0,0);
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfWing, radiusOfWing, thicknessOfWing, wingQuality, wingQuality);
	glPopMatrix();
	//glDisable(GL_POLYGON_STIPPLE);

	//and the body
	buildGLBrick((float)10,(float)20,2.5*radiusOfWing);
}

void buildBlockyStudentCenter(void)
{
	glPushMatrix();
	//glTranslatef(0,150,0);
	//glScalef(0.1,0.1,0.1);
	
	float ssAlphaValue = 1.0;
	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleBrick);
	//glColor4f(0,0,(float)0.5,ssAlphaValue); //this is the nice shade of blue you miss
	//glColor4f(.7,.11,.7, ssAlphaValue);
	glColor4f((float)130.0/255.0,(float)43/255.0,0, ssAlphaValue);
	glPushMatrix();
		glTranslatef(-200,300,-400); //minZ: -700; maxZ: -100
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.6,.10,.6,ssAlphaValue);
	//glColor4f(.9,.9,.9, ssAlphaValue);
	glPushMatrix();
		glTranslatef(0,300,-300); //minZ: -700; maxZ: 300
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.7,.11,.7,ssAlphaValue);
	//glColor4f(.8,.8,.8, ssAlphaValue);
	glPushMatrix();
		glTranslatef(300,300,-400);
		buildGLCube(600);
	glPopMatrix();
	//glColor4f(.6,.10,.0,ssAlphaValue);
	//glColor4f(.7,.7,.7, ssAlphaValue);
	glPushMatrix();
		glTranslatef(200,500,-700); //minZ: -1200; maxZ: 300
		buildGLCube(1000); //range of X by now: [-500, 700].
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,300,-1100); //minZ: -1400; maxZ: 300
		buildGLCube(600);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,600,-1400); //minZ: -2000; maxZ: 300
		buildGLCube(1200);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-200,600,-2100); //minZ: -2400; maxZ: 300
		buildGLBrick(800,1200,600); //range of X by now: [-600, 700].
		//buildGLCube(800);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(600,700,-1350); //range of X by now: [-600, 950]
		buildGLCube(700);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(600,700,-850);
		buildGLCube(700);
	glPopMatrix();
	//if((0.5*buildSize) + (translateX) > currMaxX) {currMaxX = (0.5*buildSize) + (translateX);}
	//if((-0.5*buildSize) + (translateX) < currMinX) {currMinX = (-0.5*buildSize) + (translateX);}
	//if((0.5*buildSize) + (translateZ) > currMaxX) {currMaxX = (0.5*buildSize) + (translateX);}
	//if((-0.5*buildSize) + (translateZ) < currMinX) {currMinX = (-0.5*buildSize) + (translateX);}


	//glColor4f(0,0,(float)0.5,(float)0.5);
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	double radiusOfCylinder = 300;
	int quality = 55;
	glPushMatrix();
		glTranslatef(0,4.0*radiusOfCylinder,-2500); //minZ: -2800; maxZ: 300
		glRotatef(90,1,0,0);
		gluCylinder(quadric, radiusOfCylinder, radiusOfCylinder, 4.0*radiusOfCylinder, quality, quality);
	glPopMatrix();
	glDisable(GL_POLYGON_STIPPLE);
	glPopMatrix();
}

void buildFakeApple(void) //create a fake Apple logo
{
	glPushMatrix();
		glColor3f(1,1,1);
		buildGLBrick(60,60,4);
		glTranslatef(20,0,0);
		glColor3f(.2,.2,.5);
		buildGLBrick(20,20,4.1);
		glTranslatef(-20,0,0);
		glTranslatef(5,48,0);
		glColor3f(1,1,1);
		glRotatef(-45,0,0,1);
		buildGLBrick(10,28,4);
	glPopMatrix();
}

void buildHeadphones()
{
	glPushMatrix();
		glTranslatef(70,0,0);
		buildGLCube(50); //one cup
		glTranslatef(-140,0,0);
		buildGLCube(50); //the other cup
		glTranslatef(0,25 + 25,0);
		buildGLBrick(20,50,30); //upper band for one cup
		glTranslatef(140,0,0);
		buildGLBrick(20,50,30); //upper band for another cup
		glTranslatef(-70,0,0);
		glTranslatef(0,25,0);
		buildGLBrick(140,10,20); //topmost connecting band
	glPopMatrix();
}

void buildRudementaryPerson ()
{
	glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(-50,25,0);
		buildGLCube(50); //start with the feet. Its right foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some design on that foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //more design for that foot
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(100,0,0); //equivalent to resetting, then going (30,25,-200)
		buildGLCube(50); //Its left foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some more design, this time for the left foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //still more design
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(-50, 150, 0); //for the torso: want x at 0 so 30-30, y at 150 so 25+75, z at same depth (for now)
		buildGLBrick(200,200,90); //the torso; should not be visible if clothes are on properly!
		glColor3f(0,1,0);
		buildGLBrick(200.1,100.01,95); //part of the shirt
		glColor3f(0.5,0.5,0.0);
		glTranslatef(0,-60,0);
		buildGLBrick(200.01,100.01,100); //part of the shorts
		glColor3f(0,0,0);
		glTranslatef(0,-40,0);
		buildGLBrick(10.01,50.01,102); //the crotch
		glTranslatef(0,100,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(-150,0,0); //put one arm out to the viewer's left by default
		buildGLBrick(40,50,40); //its right arm
		glTranslatef(300,0,0); //put the other arm out to the viewer's right by default
		buildGLBrick(40,50,40); //and its left arm
		glColor3f(0.5,0.5,0.5);
		glTranslatef(0,-60,0);
		buildGLBrick(60,100,5); //shell of the tablet
		glColor3f(0.4,0.4,0.4);
		buildGLBrick(55,90,5.1); //screen within the tablet
		glTranslatef(0,0,3);
		glScalef(0.5,0.5,0.5);
		buildFakeApple(); //Apple logo
		glScalef(2,2,2);
		glTranslatef(0,0,-3);
		glTranslatef(0,60,0);
		glTranslatef(-150,0,0);
		glTranslatef(0,50,0);
		glColor3f(0.5,0,0); //color of the T-shirt
		buildGLBrick(200.2,100,102); //T-shirt part: main body primary
		glTranslatef(0,10,0);
		buildGLBrick(280.2,65,95); //T-shirt part: main body shoulders
		glTranslatef(0,-10,0);
		glTranslatef(-150,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 1
		glTranslatef(300,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 2
		glTranslatef(-150,0,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(0,46,0);
		buildGLBrick(48,7,100.3); //the neck hole
		glTranslatef(0,90,0); //want the head just above the torso
		buildGLCube(100); //and the head
		glColor3f(.5,0,.5);
		buildHeadphones(); //throw on some headphones
	glPopMatrix();
}

void buildBystander (float * posX, float* posZ, float* angle)
{
	//glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO);

	helperForPositionOfLegs += 1;
	int legChangeAfterNCycles = 40;
	if (helperForPositionOfLegs >= 2 * legChangeAfterNCycles)
	{
		helperForPositionOfLegs = 0;
	}
	glPushMatrix();
		automatedBystanderPathing (posX, posZ, angle);
		if (helperForPositionOfLegs < legChangeAfterNCycles)
		{
			glColor3f(1,1,1);
			glTranslatef(-50,25,0);
			buildGLCube(50); //start with the feet. Its right foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some design on that foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //more design for that foot
			glTranslatef(0,0,-25.02);
			glColor3f(1,1,1);
			glTranslatef(100,0,10); //equivalent to resetting, then going (30,25,-200)
			buildGLCube(50); //Its left foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some more design, this time for the left foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //still more design
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
		}
		else if(helperForPositionOfLegs < 2*legChangeAfterNCycles)
		{
			glColor3f(1,1,1);
			glTranslatef(-50,25,10);
			buildGLCube(50); //start with the feet. Its right foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some design on that foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //more design for that foot
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
			glColor3f(1,1,1);
			glTranslatef(100,0,10); //equivalent to resetting, then going (30,25,-200)
			buildGLCube(50); //Its left foot
			glColor3f(0,0,0);
			glTranslatef(0,0,25.01);
			buildEquilateralTriangle(51); //do some more design, this time for the left foot
			glTranslatef(0,0,0.01);
			glColor3f(0.5,0,1);
			buildEquilateralTriangle(51); //still more design
			glTranslatef(0,0,-25.02);
			glTranslatef(0,0,-10);
		}
		glColor3f(1,1,1);
		glTranslatef(-50, 150, 0); //for the torso: want x at 0 so 30-30, y at 150 so 25+75, z at same depth (for now)
		buildGLBrick(200,200,90); //the torso; should not be visible if clothes are on properly!
		glColor3f(0,.2,.9);
		buildGLBrick(200.1,100.01,95); //part of the shirt
		glColor3f(0.5,0.5,0.0);
		glTranslatef(0,-60,0);
		buildGLBrick(200.01,100.01,100); //part of the shorts
		glColor3f(0,0,0);
		glTranslatef(0,-40,0);
		buildGLBrick(10.01,50.01,100.1); //the crotch
		glTranslatef(0,100,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(-150,0,0); //put one arm out to the viewer's left by default
		buildGLBrick(40,50,40); //its right arm
		glTranslatef(300,0,0); //put the other arm out to the viewer's right by default
		buildGLBrick(40,50,40); //and its left arm
		glColor3f(0.5,0.5,0.5);
		glTranslatef(0,-60,0);
		//buildGLBrick(60,100,5); //shell of the tablet
		//glColor3f(0.4,0.4,0.4);
		//buildGLBrick(55,90,5.1); //screen within the tablet
		glTranslatef(0,0,3);
		//glScalef(0.5,0.5,0.5);
		//buildFakeApple(); //Apple logo
		//glScalef(2,2,2);
		glTranslatef(0,0,-3);
		glTranslatef(0,60,0);
		glTranslatef(-150,0,0);
		glTranslatef(0,50,0);
		glColor3f(0.2,0,0); //color of the T-shirt
		buildGLBrick(200.2,100,102); //T-shirt part: main body primary
		glTranslatef(0,10,0);
		buildGLBrick(280.2,65,95); //T-shirt part: main body shoulders
		glTranslatef(0,-10,0);
		glTranslatef(-150,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 1
		glTranslatef(300,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 2
		glTranslatef(-150,0,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(0,46,0);
		buildGLBrick(48,7,100.3); //the neck hole
		glTranslatef(0,90,0); //want the head just above the torso
		buildGLCube(100); //and the head
		glColor3f(.5,.5,.5);
		buildHeadphones(); //throw on some headphones

	glPopMatrix();
	//glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void buildBlockyTree(int color)
{
	float sizeOfCubeyBranches = 50;
	float heightOfTrunk = 700;
	glColor3f((float)107.0/255.0,(float)69.0/255.0,0);

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleFine);
	buildGLBrick(45,heightOfTrunk,45); //build the trunk of the tree
	glDisable(GL_POLYGON_STIPPLE);

	glPushMatrix();

	if (color == PINK)
	{
		glColor3f((float)255/255.0,(float)176/255.0,(float)254/255.0);
	}
	else if (color == GREEN)
	{
		glColor3f((float)129/255.0,(float)255/255.0,(float)120/255.0);
	}
	else if (color == BLUE)
	{
		glColor3f((float)122/255.0,(float)204/255.0,(float)255/255.0);
	}
	else if (color == YELLOW)
	{
		glColor3f((float)255/255.0,(float)250/255.0,(float)110/255.0);
	}
	else
	{
		glColor3f(0.5,0.5,0.5);
	}
	glTranslatef(-35,0.5*heightOfTrunk,-35);

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(stippleStyleFine);
	buildGLCube(.35*heightOfTrunk);
	glDisable(GL_POLYGON_STIPPLE);

	glTranslatef(60,.5*sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(-120,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,60);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,-120);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(120,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(-60,sizeOfCubeyBranches,60);
	buildGLCube(sizeOfCubeyBranches);
	glTranslatef(0,sizeOfCubeyBranches,0);
	buildGLCube(sizeOfCubeyBranches);

	glPopMatrix();
}

void buildCloudyCloud(int color, float thickness, float alpha)
{
	int qualityM = 40, qualityN = 20, qualityP = 10, qualityT = 5;
	int quality = qualityP;
	if (color == PINK)
	{
		glColor4f((float)255/255.0,(float)176/255.0,(float)254/255.0,alpha);
	}
	else if (color == GREEN)
	{
		glColor4f((float)129/255.0,(float)255/255.0,(float)120/255.0,alpha);
	}
	else if (color == BLUE)
	{
		glColor4f((float)122/255.0,(float)204/255.0,(float)255/255.0,alpha);
	}
	else if (color == YELLOW)
	{
		glColor4f((float)255/255.0,(float)250/255.0,(float)110/255.0,alpha);
	}
	else
	{
		glColor4f(0.5,0.5,0.5,alpha);
	}
	GLUquadricObj *quadric=gluNewQuadric();
	gluQuadricNormals(quadric, GLU_SMOOTH);
	gluSphere(quadric, thickness, quality,quality);

	glPushMatrix();
		glTranslatef(-thickness,.5*thickness,0);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(thickness,.5*thickness,0);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(1.5*thickness,0,.25*thickness);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-1.5*thickness,0,.25*thickness);
		gluSphere(quadric, thickness, quality,quality);
	glPopMatrix();
}

void giantSquareAsManyTinySquares(int lengthOfSides, int divisionsToMake) //grass is more or less a square
{
	glPushMatrix();
	//glTranslatef((-lengthOfSides),0,(-lengthOfSides));
	//glTranslatef((lengthOfSides/divisionsToMake)/2,0,(lengthOfSides/divisionsToMake)/2);
	for (int i = 0; i < lengthOfSides; i+=(lengthOfSides/divisionsToMake))
	{
		for (int j = 0; j < lengthOfSides; j+=(lengthOfSides/divisionsToMake))
		{
			//for (int k = 0; k < lengthOfSides; k+=(lengthOfSides/divisionsToMake))
			//{
				glPushMatrix();
					glTranslatef(i-(lengthOfSides/2),0,j-(lengthOfSides/2));
					//glRotatef(90,1,0,1);
					buildGLRectangleH(-lengthOfSides/divisionsToMake,lengthOfSides/divisionsToMake,-lengthOfSides/divisionsToMake,lengthOfSides/divisionsToMake);				
				glPopMatrix();
			//}
		}
	}
	glPopMatrix();
}

//method to help determine, with collision detection, where the tree trunks are -- 
//		aka, helps determine what region to avoid.
void determineTreeBounds(float xTranslation, float zTranslation, int treeCount)
{
	//for collision detection, assume you only want to avoid the trunk.
	//the size of the trunk is located in the buildBlockyTree method; at the time of writing, trunks are ~50 units thick and wide
	if (detectCollisionAreas && treeCount < maxNumberOfTrees)
	{
	int halfTreeTrunk = 15; //represents half the width and half the depth of the tree trunk, plus a little leeway
		//just make a square around the trunk, representing width and depth; no need to worry about height
	treesMinX[treeCount] = xTranslation - halfTreeTrunk;
	treesMaxX[treeCount] = xTranslation + halfTreeTrunk;
	treesMinZ[treeCount] = zTranslation - halfTreeTrunk;
	treesMaxZ[treeCount] = zTranslation + halfTreeTrunk;
	treeInSlot[treeCount] = true;
	}
}

void buildFakeTundra() //this is the test plane, aka fake tundra, drawn beneath the person to verify movement in the proper direction
{
	float halfSizeOfTundra = 4000;

	if (glLightEnableInStep == 1 || glLightEnableInStep == 2)
	{
		glColor3f(1,1,1);
	}
	else
	{
		glColor3f((float)44.0/255.0,(float)135.0/255.0,0);
	}
	giantSquareAsManyTinySquares(halfSizeOfTundra*2, 120);


	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,0,0,1);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,0,0,-1);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,1,0,0);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,-halfSizeOfTundra,0);
	glRotatef(90,-1,0,0);
	glTranslatef(0,halfSizeOfTundra,0);
	glBegin(GL_POLYGON);
		glColor3f(.2,.2,.2);
		glVertex3f(-halfSizeOfTundra,30,-halfSizeOfTundra);
		glColor3f(.3,.3,.3);
		glVertex3f(-halfSizeOfTundra, 30, halfSizeOfTundra);
		glColor3f(.4,.4,.4);
		glVertex3f(halfSizeOfTundra,30,halfSizeOfTundra);
		glColor3f(.5,.5,.5);
		glVertex3f(halfSizeOfTundra,30,-halfSizeOfTundra);
	glEnd();
	glPopMatrix();
	
	//for collision detection, assume you only want to avoid the trunk.
	//the size of the trunk is located in the buildBlockyTree method; at the time of writing, trunks are ~50 units thick and wide
	int treeCount = 0;
	
	glPushMatrix();
		glTranslatef(600,300,1000);
		buildBlockyTree(PINK);
	glPopMatrix();
	determineTreeBounds(600,1000,treeCount);
	treeCount++;
	
	glPushMatrix();
		glTranslatef(900,300,650);
		buildBlockyTree(BLUE);
	glPopMatrix();
	determineTreeBounds(900,650,treeCount);
	treeCount++;


	glPushMatrix();
		glTranslatef(900,300,1800);
		buildBlockyTree(GREEN);
	glPopMatrix();
	determineTreeBounds(900,1800,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(400,300,800);
		buildBlockyTree(YELLOW);
	glPopMatrix();
	determineTreeBounds(400,800,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(-1400,300,-450);
		buildBlockyTree(BLUE);
	glPopMatrix();
	determineTreeBounds(-1400,-450,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(-1000, 300, -1600);
		buildBlockyTree(PINK);
	glPopMatrix();
	determineTreeBounds(-1000,-1600,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(1550, 300, -800);
		buildBlockyTree(OTHER);
	glPopMatrix();
	determineTreeBounds(1550,-800,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(-150, 300, 1500);
		buildBlockyTree(BLUE);
	glPopMatrix();
	determineTreeBounds(-150,1500,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(1600, 300, -700);
		buildBlockyTree(OTHER);
	glPopMatrix();
	determineTreeBounds(1600,-700,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(-900, 300, 1200);
		buildBlockyTree(YELLOW);
	glPopMatrix();
	determineTreeBounds(-900,1200,treeCount);
	treeCount++;

	glPushMatrix();
		glTranslatef(1400, 300, 1800);
		buildBlockyTree(OTHER);
	glPopMatrix();
	determineTreeBounds(1400,1800,treeCount);
	//treeCount++;
}

void myinit()
{
 	
	if (flashRed && !ignoreCollisionDetection)
	{
		glClearColor((float)208.0/255.0, (float)2.0/255.0, (float)35.0/255.0, 1.0); /*flash red background */
		flashRed = false;
	}
	else if (ignoreCollisionDetection)
	{
		flashRed = false;
		glClearColor((float)2.0/255.0, (float)158.0/255.0, (float)35.0/255.0, 1.0); /*display a green background */
	}
	else
	{
		glClearColor((float)39.0/255.0, (float)85.0/255.0, (float)125.0/255.0, 1.0); /*blue background */
	}
      
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(currentFieldOfViewY, 1, 0.1, 8000); //sorta defines how much of the world we can roam

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//change lookat (center) Y back to 0 if broken
	glRotatef(cameraRotateUpDownTheta,1,0,0);
	gluLookAt(-1000*sin((thetaToRotatePerson * PI / 180.0)) + currentXCoordinate, 200 + translateYVal, 0 - 1000*cos((thetaToRotatePerson * PI / 180.0)) + currentZCoordinate, /* from where do you want to look? aka the camera XYZ */
		-500*sin((thetaToRotatePerson * PI / 180.0)) + currentXCoordinate, 100 + translateYVal, 0 - 500*cos((thetaToRotatePerson * PI / 180.0)) + currentZCoordinate, /* where is the thing you want to see? use an X, Y, and Z! */
			0, 1, 0); /* desired normal vector, with the origin as your imaginary start and this XYZ as the end/the direction. */
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
}

void buildCloudCollection()
{
	int colorPositionCount = 1;
	for (float xTrans = -2000; xTrans < 2001; xTrans= xTrans+800)
	{
		for (float zTrans = -2000; zTrans < 2001; zTrans = zTrans+800)
		{
		glPushMatrix();
			glTranslatef(xTrans*1.5,0,zTrans*1.5);
			switch(colorPositionCount) {
			case PINK:
				buildCloudyCloud(PINK,(float)70,(float)0.5);
				colorPositionCount++;
				break;
			case GREEN:
				buildCloudyCloud(GREEN,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case BLUE:
				buildCloudyCloud(BLUE,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case YELLOW:
				buildCloudyCloud(YELLOW,(float)70,(float)0.3);
				colorPositionCount++;
				break;
			case OTHER:
				buildCloudyCloud(OTHER,(float)70,(float)0.3);
				colorPositionCount = PINK;
				break;
			}
		glPopMatrix();
		}
	}
}


void performLightingOperations()
{	
	//DO ALL THE LIGHTING STUFF
	float amb_light_color[] = {generalLightMagnitude/3,generalLightMagnitude/3,generalLightMagnitude/3,5}; //"color" for GLOBAL ambient lighting 
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, amb_light_color ); //turn on GLOBAL ambient lighting
	float diffuse_light_color[] = {generalLightMagnitude,generalLightMagnitude,generalLightMagnitude,1}; //"color" for diffuse lighting element of the spotlight; should be white
	float diffuse_light_position[] = {0,200,75,.5};
	if (renderCouchInsteadOfPerson)
	{
		diffuse_light_position[2] = -550;
	}

	
	
	float lv0_amb[] = {generalLightMagnitude,generalLightMagnitude,generalLightMagnitude,1};
	float lv0_direction[] = {0,0,10};
	
	glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE ) ;
	glEnable(GL_COLOR_MATERIAL); //use the colors as set up in earlier projects, ignore other material properties

	glPushMatrix();
		glTranslatef(currentXCoordinate,0+translateYVal,currentZCoordinate);
		glRotatef(thetaMultiplier * thetaToRotatePerson,0,1,0);
		glLightfv(GL_LIGHT0,GL_POSITION,diffuse_light_position); //Light0 is the singular spotlight, aka FLASHLIGHT MODE
		glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lv0_direction );
		glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 90); // angle is 0 to 180
		glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 70); // exponent is 0 to 128
	glPopMatrix();

	float light1_position[] = {0,200,125,.5};
	glPushMatrix();
		glTranslatef(currentXCoordinate,0+translateYVal,currentZCoordinate);
		glRotatef(thetaToRotatePerson-15,0,1,0);
		glLightfv(GL_LIGHT1,GL_POSITION,light1_position); //Light1 is part of CUPID MODE
		glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, lv0_direction );
		glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 90); // angle is 0 to 180
		glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 75); // exponent is 0 to 128
	glPopMatrix();

	float light2_position[] = {0,200,125,.5};
	glPushMatrix();
		glTranslatef(currentXCoordinate,0+translateYVal,currentZCoordinate);
		glRotatef(thetaToRotatePerson+15,0,1,0);
		glLightfv(GL_LIGHT2,GL_POSITION,light2_position); //Light2 is also part of CUPID MODE
		glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, lv0_direction );
		glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 90); // angle is 0 to 180
		glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 75); // exponent is 0 to 128
	glPopMatrix();

	//float diffuse_light3_position[] = {55,2000,0,0};
	float diffuse_light_position_v2[] = {0,600,0,.5};
	float lv3_direction[] = {0,-10,0};
	glPushMatrix();
		glTranslatef(currentXCoordinate,0+translateYVal,currentZCoordinate);
		glLightfv(GL_LIGHT3,GL_POSITION,diffuse_light_position_v2); //Light3 is part of CUPID MODE
		glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, lv3_direction );
		glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, 85); // angle is 0 to 180
		glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 30); // exponent is 0 to 128
	glPopMatrix();

	float diffuse_light4_position[] = {-55,1000,0,0};
	float lv4_direction[] = {0,-10,0};
	glPushMatrix();
		glTranslatef(currentXCoordinate,0+translateYVal,currentZCoordinate);
		glLightfv(GL_LIGHT4,GL_POSITION,diffuse_light_position_v2); //Light4 is also part of CUPID MODE
		glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, lv4_direction );
		glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 85); // angle is 0 to 180
		glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 30); // exponent is 0 to 128
	glPopMatrix();


	float light5_direction[] = {0,0,-100};
	float light5_position[] = {0,0,0, 0};
	
	glPushMatrix(); //give the sun's original color a white glow/shine.
		glTranslatef(-780,1400+300,0);
		glLightfv(GL_LIGHT5,GL_POSITION,diffuse_light_position);
		glLightfv(GL_LIGHT5, GL_SPOT_DIRECTION, light5_direction);
		glLightf(GL_LIGHT5, GL_SPOT_CUTOFF, 90); // angle is 0 to 180
		glLightf(GL_LIGHT5, GL_SPOT_EXPONENT, 110); // exponent is 0 to 128
	glPopMatrix();

	glPushMatrix(); //Light6 also hits the sun, but it is switched on (replacing light5) to give it a different color/glow.
		glTranslatef(-780,1400+300,0);
		glLightfv(GL_LIGHT6,GL_POSITION,diffuse_light_position);
		glLightfv(GL_LIGHT6, GL_SPOT_DIRECTION, light5_direction);
		glLightf(GL_LIGHT6, GL_SPOT_CUTOFF, 90); // angle is 0 to 180
		glLightf(GL_LIGHT6, GL_SPOT_EXPONENT, 110); // exponent is 0 to 128
	glPopMatrix();


	//handling the other components of Light0, or FLASHLIGHT MODE
	glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse_light_color);
	glLightfv(GL_LIGHT0,GL_AMBIENT, lv0_amb);
	glLightfv(GL_LIGHT0,GL_SPECULAR, lv0_amb);

	float lv1_amb_intensity[] = {.5,0,1,1}; //Light1 is part of CUPID MODE; one of the forward facing lights
	glLightfv(GL_LIGHT1,GL_AMBIENT, lv1_amb_intensity);
	glLightfv(GL_LIGHT1,GL_SPECULAR, lv1_amb_intensity);
	glLightfv(GL_LIGHT1,GL_DIFFUSE, lv1_amb_intensity);

	float lv2_amb_intensity[] = {1,0,.5,1}; //Light2 is also part of CUPID MODE; another of the forward facing lights
	glLightfv(GL_LIGHT2,GL_AMBIENT, lv2_amb_intensity);
	glLightfv(GL_LIGHT2,GL_SPECULAR, lv2_amb_intensity);
	glLightfv(GL_LIGHT2,GL_DIFFUSE, lv2_amb_intensity);

	float lv3_amb_intensity[] = {0,0,1,0}; //Light3 is part of CUPID MODE; one of the downward-firing spotlights
	glLightfv(GL_LIGHT3,GL_AMBIENT, lv3_amb_intensity);
	glLightfv(GL_LIGHT3,GL_SPECULAR, lv3_amb_intensity);
	glLightfv(GL_LIGHT3,GL_DIFFUSE, lv3_amb_intensity);

	float lv4_amb_intensity[] = {1,0,0,0}; //Light4 is also part of CUPID MODE; another of the downward-firing spotlights
	glLightfv(GL_LIGHT4,GL_AMBIENT, lv4_amb_intensity);
	glLightfv(GL_LIGHT4,GL_SPECULAR, lv4_amb_intensity);
	glLightfv(GL_LIGHT4,GL_DIFFUSE, lv4_amb_intensity);


	float lv5_colour[] = {(float)237/255,(float)114/255,(float)7/255,1}; //As light5 makes the sun "shine", we ideally make this yellowish white, or just white.
	glLightfv(GL_LIGHT5,GL_AMBIENT, lv5_colour);
	glLightfv(GL_LIGHT5,GL_SPECULAR, lv5_colour);
	glLightfv(GL_LIGHT5,GL_DIFFUSE, lv5_colour);
	
	float lv6_amb_intensity[] = {0,0,1,0}; //with light6, change the "color" of the sun compared to light5; hitting the sun with a different colored light for CUPID MODE. 
	glLightfv(GL_LIGHT6,GL_AMBIENT, lv6_amb_intensity);
	glLightfv(GL_LIGHT6,GL_SPECULAR, lv6_amb_intensity);
	glLightfv(GL_LIGHT6,GL_DIFFUSE, lv6_amb_intensity);

	if (glLightEnableInStep == 0)
	{ //light in front of student, aka FLASHLIGHT MODE
		glEnable(GL_LIGHT0); //enable what is set up above as our FLASHLIGHT spotlight
		glEnable(GL_LIGHT5); //give the sun some glow
		glEnable(GL_LIGHTING);
		

		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHT3);
		glDisable(GL_LIGHT4);
		glDisable(GL_LIGHT6);
	}
	else if (glLightEnableInStep == 1)
	{ //other set of lights, aka CUPID MODE
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT1);
		glEnable(GL_LIGHT2);
		glEnable(GL_LIGHT3);
		glEnable(GL_LIGHT4);
		glEnable(GL_LIGHT6);

		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHT5);
	}
	else if (glLightEnableInStep == 2)
	{ //both sets of lights, so FLASHLIGHT + CUPID MODE
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT1);
		glEnable(GL_LIGHT2);
		glEnable(GL_LIGHT0);
		glEnable(GL_LIGHT3);
		glEnable(GL_LIGHT4);
		glEnable(GL_LIGHT5);

		glDisable(GL_LIGHT6);
	}
	else if (glLightEnableInStep == 3)
	{ //ambient light only, SO ALL LIGHTS OUT
		glEnable(GL_LIGHTING);

		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHT3);
		glDisable(GL_LIGHT4);
		glDisable(GL_LIGHT5);
		glDisable(GL_LIGHT6);
	}
	else
	{ //just a default case in the event that we go outside the boundary
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHT3);
		glDisable(GL_LIGHT4);
		glDisable(GL_LIGHT5);
		glDisable(GL_LIGHT6);
		glDisable(GL_LIGHTING);
	}
}

void display( void )
{
	int maxLoops = 10000;
	int currentLoopCount = 1;
	if (personAutoMove)
	{
		maxLoops = 10000;
	}
	else
	{
		maxLoops = currentLoopCount + 1;
	}
	
	if (ignoreCollisionDetection)
	{
		currentXCoordinate = overrideXCoord;
		currentZCoordinate = overrideZCoord;
	}

	myinit(); //this is the typical init function, but it also holds the camera config info

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  /*clear the window */
	//END SETUP; BEGIN DRAWING THINGS

	performLightingOperations();
	
	buildFakeLogo(100); //this acts as our initial positioning system
	//makeASun(350);

	//fake sun high in the sky, plus some clouds
	glPushMatrix();
		glTranslatef(-780,1400+900,-3000);
		makeASun(350); //build the actual sun
		glTranslatef(0,-900,3000);
		buildCloudCollection();
	glPopMatrix();

	//build fake tundra, with built-in fake trees that look like roman candles
	buildFakeTundra();

	//and the main person
	glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
		if(flyFreeFly) //then make the person high in the sky, and don't translate him; only move the camera
		{
			if(personAutoMove){
				automatedStudentPathing(&currentXCoordinate,&currentZCoordinate,&thetaToRotatePerson);
			}
			else if (returnToLastPosition)
			{
				resumeManualStudentCtrl(&currentXCoordinate,&currentZCoordinate,&thetaToRotatePerson);
				returnToLastPosition = false;
			}
			glTranslatef(0,900,0);
			glScalef(currentScalingMagnitude,currentScalingMagnitude,currentScalingMagnitude);
			//glRotatef(thetaMultiplier * thetaToRotatePerson,0,1,0);
			if (!renderCouchInsteadOfPerson){
				buildRudementaryPerson();
			}
			else
			{
				glRotatef(180,0,1,0);
				buildCouch();
			}
		}
		else if(!flyFreeFly)
		{
			if(personAutoMove){
				automatedStudentPathing(&currentXCoordinate,&currentZCoordinate,&thetaToRotatePerson);
			}
			else if (returnToLastPosition)
			{
				resumeManualStudentCtrl(&currentXCoordinate,&currentZCoordinate,&thetaToRotatePerson);
				returnToLastPosition = false;
			}
			glTranslatef(currentXCoordinate,30+translateYVal,currentZCoordinate);
			glScalef(currentScalingMagnitude,currentScalingMagnitude,currentScalingMagnitude);
			glRotatef(thetaMultiplier * thetaToRotatePerson,0,1,0);
			if (!renderCouchInsteadOfPerson){
				buildRudementaryPerson();
			}
			else
			{
				glRotatef(180,0,1,0);
				buildCouch();
			}
		}
	glPopMatrix(); //...restore the state of the matrix after the person is called!

	//and since order matters for transparency, the student center
	buildBlockyStudentCenter();

	//plus some random bystanders who do nothing on their own.
	//right now, they walk around whenever you move/rotate the person, and they follow a box (affected by the pathing function)
	glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
		glTranslatef(bystanderAPosX,15,bystanderAPosZ);
		glRotatef(bystanderAngleA,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderAPosX, &bystanderAPosZ, &bystanderAngleA);
	glPopMatrix();
	glPushMatrix();
		glTranslatef(bystanderBPosX,15,bystanderBPosZ);
		glRotatef(bystanderAngleB,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderBPosX, &bystanderBPosZ, &bystanderAngleB);
	glPopMatrix(); 
	glPushMatrix();
		glTranslatef(bystanderCPosX,15,bystanderCPosZ);
		glRotatef(bystanderAngleC,0,1,0);
		glScalef(.99*currentScalingMagnitude,.99*currentScalingMagnitude,.99*currentScalingMagnitude);
		buildBystander(&bystanderCPosX, &bystanderCPosZ, &bystanderAngleC);
	glPopMatrix(); //...restore the state of the matrix after each person is made!

	//have a butterfly
	glPushMatrix();
		automatedButterflyPathing(&butterflyAPosX,&butterflyAPosY,&butterflyAPosZ,&butterflyAZig);
		glTranslatef(butterflyAPosX,butterflyAPosY+250,butterflyAPosZ);
		butterfly();
	glPopMatrix();

	glPushMatrix();
		automatedButterflyPathing(&butterflyBPosX,&butterflyBPosY,&butterflyBPosZ,&butterflyBZig);
		glTranslatef(butterflyBPosX,butterflyBPosY+250,butterflyBPosZ);
		butterfly();
	glPopMatrix();

	glPushMatrix();
		automatedButterflyPathing(&butterflyCPosX,&butterflyCPosY,&butterflyCPosZ,&butterflyCZig);
		glTranslatef(butterflyCPosX,butterflyCPosY+250,butterflyCPosZ);
		butterfly();
	glPopMatrix();

	if (detectCollisionAreas)
	{
		detectCollisionAreas = false;
	}
	glutSwapBuffers();

	while (!keyInputIRQ && currentLoopCount < maxLoops)
	{ //do all the stuff below in this here display method
		glutPostRedisplay();	
	
		currentLoopCount++; //eventually, the automatic loop unrolling will end.
	}
 }


// This function is called whenever the window size is changed
// OpenGL, in tandem with the OS, decide what to do, and provide the necessary params.
//@params: the new width and height of the display window, to assist with how to scale accordingly
//@return: [none]
void manageReshape (int w, int h)
{
	if (w < h)
	{
		glViewport (0, ((h - w) /2), (GLsizei) w, (GLsizei) w); // Set the viewport
	}
	else if (h < w)
	{
		glViewport (((w - h) /2), 0, (GLsizei) h, (GLsizei) h); // Set the viewport
	}
	else
	{
		glViewport (0, 0, (GLsizei) w, (GLsizei) h); // Set the viewport
	}
}

//called on normal key presses--for now, 0, 1
void manageNormalKeyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
		case '+':
			if (generalLightMagnitude + lightMagDelta > 1)
			{
				generalLightMagnitude = generalLightMagnitude;
			}
			else
			{
				generalLightMagnitude += lightMagDelta;
			}
		break;

		case '-' :
			if (generalLightMagnitude - lightMagDelta <= 0)
			{
				generalLightMagnitude = generalLightMagnitude;
			}
			else
			{
				generalLightMagnitude -= lightMagDelta;
			}
		break;

		case '0' :
			currentScalingMagnitude += scaleChangeMagnitude;
		break;

		case '1' :
			if (currentScalingMagnitude - scaleChangeMagnitude <= 0)
			{
				currentScalingMagnitude = currentScalingMagnitude;
			}
			else
			{
				currentScalingMagnitude -= scaleChangeMagnitude;
			}
		break;

		case '7' :
			if ((currentFieldOfViewY - fieldOfViewDelta) < 1 || (currentFieldOfViewY - fieldOfViewDelta) < (originalFieldOfViewY - 40))
			{
				currentFieldOfViewY = currentFieldOfViewY;
			}
			else
			{
				currentFieldOfViewY -= fieldOfViewDelta;
			}
		break;

		case '8' :
			if ((currentFieldOfViewY - fieldOfViewDelta) > 179 || (currentFieldOfViewY - fieldOfViewDelta) > (originalFieldOfViewY + 40))
			{
				currentFieldOfViewY = currentFieldOfViewY;
			}
			else
			{
				currentFieldOfViewY += fieldOfViewDelta;
			}
		break;
		case '4':
			for (int i = 0; i < 100; i++)
			{
				display();
			}
			break;
		case '5':
			glutPostRedisplay();
			break;
		case 'F':
		case 'f':
			flyFreeFly = !flyFreeFly;
			break;
		case 'b':
		case 'B':
			keyInputIRQ = true; //prevent drawing
			break;
		case 'A':
		case 'a':
			personAutoMove = !personAutoMove;
			if (personAutoMove)
			{
				keyInputIRQ = false; //go ahead and permit drawing
			}
			if (!personAutoMove)
			{
				returnToLastPosition = true; //prevent drawing
				keyInputIRQ = true;
			}
			break;
		case 'R':
		case 'r':
			keyInputIRQ = false; //allow drawing
			break;
		case 'L':
		case 'l':
			if (glLightEnableInStep == 0)
			{
				glLightEnableInStep = 1;
			}
			else if (glLightEnableInStep == 1)
			{
				glLightEnableInStep = 2;
			}
			else if (glLightEnableInStep == 2)
			{
				glLightEnableInStep = 3;
			}
			else if (glLightEnableInStep == 3)
			{
				glLightEnableInStep = 0;
			}
			else
			{
				glLightEnableInStep = 0;
			}
			break;
		case ' ':
			modifierKey = true;
		break;
		case 'c':
		case 'C':
			renderCouchInsteadOfPerson = !renderCouchInsteadOfPerson;
		break;
		case 'd':
		case 'D':
			ignoreCollisionDetection = !ignoreCollisionDetection;
		break;
	}
	glutPostRedisplay(); // Redraw the scene
}

void manageNormalKeyUp(unsigned char key, int x, int y)
{
	switch (key)
	{
		case ' ':
			modifierKey = false;
		break;

		

	}
	glutPostRedisplay(); // Redraw the scene
}

// called on special key pressed
void manageArrowKeyInput(int key, int x, int y) { 

	// Check which key is pressed
	//float temporaryThetaForMinus = thetaToRotatePerson; //variable used to help restrict values returned by sin and cos functions used to provide movement; see individual uses.
	//float temporaryThetaForPlus = thetaToRotatePerson; //variable used to help restrict values returned by sin and cos functions used to provide movement; see individual uses.
	thetaForTrig = thetaToRotatePerson;
	float forward_back_Multiplier = 16.0f;
	switch(key) {
		case GLUT_KEY_LEFT: // Rotate counterclockwise, and determine the direction & magnitude at which you would move once rotated.
			thetaToRotatePerson += thetaChangeMagnitude;
			while (thetaForTrig >= 360) //this will prevent the sin and cos functions from dealing with a theta value greater than 360 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				thetaForTrig -= 360;
			}
			while (thetaForTrig < 0)  //this will prevent the sin and cos functions from dealing with a theta value less than 0 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				thetaForTrig += 360;
			}
			runX = cosf(thetaForTrig * PI / 180);
			riseY = sinf(thetaForTrig * PI / 180);
		break;
		case GLUT_KEY_RIGHT: // Rotate clockwise, and determine the direction & magnitude at which you would move once rotated.
			thetaToRotatePerson -= thetaChangeMagnitude;
			while (thetaForTrig >= 360) //this will prevent the sin and cos functions from dealing with a theta value greater than 360 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				thetaForTrig -= 360;
			}
			while (thetaForTrig < 0)  //this will prevent the sin and cos functions from dealing with a theta value less than 0 degrees, which is otherwise allowed elsewhere in code, but not while determining rise & run.
			{
				thetaForTrig += 360;
			}
			runX = cosf(thetaForTrig * PI / 180);
			riseY = sinf(thetaForTrig * PI / 180);
		break;
		case GLUT_KEY_UP : // Move in the forward direction relative to the current view, based on rise and run values determined above
			if (!modifierKey)
			{
				currentXCoordinate += forward_back_Multiplier * riseY;
				currentZCoordinate += forward_back_Multiplier * runX;
			}
			else
			{
				translateYVal += 3*thetaChangeMagnitude;
			}
		break;
		case GLUT_KEY_DOWN : // Move in the reverse direction relative to the current view, based on rise and run values determined above
			if (!modifierKey){
				currentXCoordinate -= forward_back_Multiplier * riseY;
				currentZCoordinate -= forward_back_Multiplier * runX;
			}
			else
			{
				if (translateYVal - thetaChangeMagnitude > defaultTranslateYVal)
				{
					translateYVal -= 3*thetaChangeMagnitude;
				}
			}
		break; 
		case GLUT_KEY_PAGE_UP: //Make the camera look up 
			if (cameraRotateUpDownTheta > -90)
			{
				cameraRotateUpDownTheta -= thetaChangeMagnitude;
			}
			
		break;
		case GLUT_KEY_PAGE_DOWN: //Make the camera look down
			if (cameraRotateUpDownTheta < 90)
			{
				cameraRotateUpDownTheta += thetaChangeMagnitude;
			}
		break;

	}

	overrideXCoord = currentXCoordinate;
	overrideZCoord = currentZCoordinate;

	if (checkPrimaryStudentCollisionCoordinates(currentXCoordinate,currentZCoordinate))
		{
			oldXCoordinate = currentXCoordinate;
			oldZCoordinate = currentZCoordinate;
		}
	else
		{
			currentXCoordinate = oldXCoordinate;
			currentZCoordinate = oldZCoordinate;
		}

    glutPostRedisplay(); // Redraw the scene
}


void main(int argc, char** argv)
{

/* Standard GLUT initialization */

    glutInit(&argc,argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); /*as set by default*/
    glutInitWindowSize(800,800); /* 500 x 500 window by default*/
    glutInitWindowPosition(0,0); /* place window top left on display */
    glutCreateWindow("COMP-5/6400 Assignment 5"); /* window title */
	
	glutReshapeFunc(manageReshape); //defines what method to call when the user resizes a window; target function is defined above
	glutKeyboardFunc(manageNormalKeyInput);
	glutKeyboardUpFunc(manageNormalKeyUp);
	glutSpecialFunc(manageArrowKeyInput); //tells the program to be waiting for input from arrow keys; target function is defined above
    glutDisplayFunc(display); /* display callback invoked when window opened */
	glEnable(GL_DEPTH_TEST);
	//glDepthFunc(GL_LESS);
	glDepthFunc(GL_LESS);
	glShadeModel(GL_SMOOTH);

	glEnable( GL_NORMALIZE ); //normalize some of the vectors

	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	for (int arrayPosition = 0; arrayPosition < maxNumberOfTrees; arrayPosition++)
	{
		treesMinX[arrayPosition] = 0;
		treesMaxX[arrayPosition] = 0;
		treesMinZ[arrayPosition] = 0;
		treesMaxZ[arrayPosition] = 0;
		treeInSlot[arrayPosition] = false; //initialize to false, and set to true if tree exists
	}

    glutMainLoop(); /* enter event loop */
}
