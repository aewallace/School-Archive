
/*Auburn University Student Center, plus mobile person. */
/*	COMP5400 Assignment #02, version alpha       */
/*    (very low-res)                       */
/* Modified from the Two-Dimensional Sierpinski Gasket code        */
/*Albert Wallace, aew0024, 07, 13, 14 February 2014; 2/27, 3/1, 3/3, 3/4/2014                        */
/*major code assistance provided by http://www.codeproject.com/Articles/23666/OpenGL-3D-Navigation-glRotatef-glTranslatef-gluLoo */
/*secondary code assistance noted elsewhere in the code itself*/


/********************************************************************************
 *TO CONTROL the digital person (D.P.), these USER CONTROLS are available:
 ********************************************************************************/
/*
---Left mouse click moves/slides D.P. one full "step" to the left (from default position, moves one step left; from rightmost position, moves two steps)
---Right mouse click moves/slides D.P. one full "step" to the right (same type of movement as above)
---0 key increases D.P.'s size, 1 key decreases D.P.'s size (minimum size is default, maximum is undefined and he WILL begin to disappear once he grows too big)
---Left and right arrow keys rotate D.P. as if the feet were on a spinning platform
---Up and Down arrow keys result in the headphones rocketing off into space 
---    (please pardon the Beyonce' "Surfbort" reference/easter egg that appears after you keep rocketing the headphones into space)
*/

#include <stdlib.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <time.h>
#include <math.h>
#include <thread>

#define PI 3.141592653589739

float sbr = 2; //ratio by which to scale; best value to set depends on view window, etc; no forumla available
float denomRGB = 255; //to convert from 8-bit representation to float representation
float thetaChangeMagnitude = 2.5f; //used to decide how much a person rotates, in degrees, upon each arrow press
float currentTheta = 0;
float scaleChangeMagnitude = 0.5f;
float currentScalingMagnitude = 1.0f;

float defaultXPosition = 500;
float defaultYPosition = 500;


float destinationXChange = 250;
float destinationYChange = 250;


float deltaXPosition = 2;
float currentXPosition = defaultXPosition-deltaXPosition;
float currentYPosition = defaultYPosition;

float destinationXPosition = defaultXPosition;

float headphoneYAdditionToPosition = 0;

bool goingToDefault = true;
bool goingToLeft = false;
bool goingToRight = false;


void buildGLRectangle(float xMin, float xMax, float yMin, float yMax) //used to speed up the creation of a GL QUAD that will only be a rectangle or square
{
	glBegin(GL_QUADS); 
		glVertex2f(xMin*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMax*sbr);
		glVertex2f(xMin*sbr,yMax*sbr);
	glEnd();
}

void surfbort()
{
	glColor3f(.1,.1,.1);
	buildGLRectangle(-200,200,-50,50);
	glColor3f(1,1,1);
	glBegin(GL_LINE_STRIP);
		glVertex3f(-175,45,0.1);
		glVertex3f(-195,45,0.1);
		glVertex3f(-195,3,0.1);
		glVertex3f(-175,3,0.1);
		glVertex3f(-175,-40,0.1);
		glVertex3f(-195,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-160,45,0.1);
		glVertex3f(-160,-40,0.1);
		glVertex3f(-135,-40,0.1);
		glVertex3f(-135,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-120,-40,0.1);
		glVertex3f(-120,45,0.1);
		glVertex3f(-90,45,0.1);
		glVertex3f(-90,2,0.1);
		glVertex3f(-120,2,0.1);
		glVertex3f(-90,-40,0.1);
	glEnd();
	
	glBegin(GL_LINE_STRIP);
		glVertex3f(-80,-40,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-40,45,0.1);
		glVertex3f(-80,45,0.1);
		glVertex3f(-80,2,0.1);
		glVertex3f(-45,2,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(-35,45,0.1);
		glVertex3f(-35,-40,0.1);
		glVertex3f(-5,-40,0.1);
		glVertex3f(-35,2,0.1);
		glVertex3f(-5,2,0.1);
		glVertex3f(-5,45,0.1);
		glVertex3f(-35,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(0,45,0.1);
		glVertex3f(0,-40,0.1);
		glVertex3f(30,-40,0.1);
		glVertex3f(30,45,0.1);
		glVertex3f(0,45,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(40,-40,0.1);
		glVertex3f(40,45,0.1);
		glVertex3f(70,45,0.1);
		glVertex3f(70,2,0.1);
		glVertex3f(40,2,0.1);
		glVertex3f(70,-40,0.1);
	glEnd();
	glBegin(GL_LINE_STRIP);
		glVertex3f(80,45,0.1);
		glVertex3f(110,45,0.1);
		glVertex3f(95,45,0.1);
		glVertex3f(95,-40,0.1);
	glEnd();
	
}

void buildFakeLogo(float lengthOfSides) //this is the test cube, aka the logo, that happens to be shown in the lower left
{
	//face one -- parallel to XY plane, positive
	glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face four --parallel to YZ plane, negative
	glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}

void buildGLCube(float lengthOfSides)
{
	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,-0.5*lengthOfSides);
		glVertex3f(-0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
		glVertex3f(0.5*lengthOfSides,-0.5*lengthOfSides,0.5*lengthOfSides);
	glEnd();
}

void buildGLBrick(float width, float height, float depth)
{
	//face one -- parallel to XY plane, positive
	//glColor3f(0,0,0);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face two -- parallel to XY plane, negative
	//glColor3f(0.20,0.20,0.20);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
	glEnd();
	//face three -- parallel to YZ plane, positive
	//glColor3f(0.40,0.40,0.40);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face four --parallel to YZ plane, negative
	//glColor3f(0.60,0.60,0.60);
	glBegin(GL_POLYGON);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face five -- parallel to XZ plane, positive
	//glColor3f(0.80,0.80,0.80);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,0.5*height,0.5*depth);
		glVertex3f(0.5*width,0.5*height,0.5*depth);
	glEnd();
	//face six -- parallel to XZ plane, negative
	//glColor3f(1,1,1);
	glBegin(GL_POLYGON);
		glVertex3f(0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,-0.5*depth);
		glVertex3f(-0.5*width,-0.5*height,0.5*depth);
		glVertex3f(0.5*width,-0.5*height,0.5*depth);
	glEnd();
}

void buildEquilateralTriangle(float lengthOfSide)
{
	glBegin(GL_TRIANGLES);
		glVertex3f(0,0,0);
		glVertex3f(-0.5*lengthOfSide,-.5*lengthOfSide*sqrt(3),0);
		glVertex3f(0.5*lengthOfSide,-.5*lengthOfSide*sqrt(3),0);
	glEnd();
}

void buildFakeApple() //create a fake Apple logo
{
	glPushMatrix();
		glColor3f(1,1,1);
		buildGLBrick(60,60,4);
		glTranslatef(20,0,0);
		glColor3f(.2,.2,.5);
		buildGLBrick(20,20,4.1);
		glTranslatef(-20,0,0);
		glTranslatef(5,48,0);
		glColor3f(1,1,1);
		glRotatef(-45,0,0,1);
		buildGLBrick(10,28,4);
	glPopMatrix();
}

void buildHeadphones()
{
	glPushMatrix();
		glTranslatef(70,0,0);
		buildGLCube(50); //one cup
		glTranslatef(-140,0,0);
		buildGLCube(50); //the other cup
		glTranslatef(0,25 + 25,0);
		buildGLBrick(20,50,30); //upper band for one cup
		glTranslatef(140,0,0);
		buildGLBrick(20,50,30); //upper band for another cup
		glTranslatef(-70,0,0);
		glTranslatef(0,25,0);
		buildGLBrick(140,10,20); //topmost connecting band
		glTranslatef(0,55,0);
		//surfbort();
	glPopMatrix();
}

void buildRudementaryPerson ()
{
	glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(-50,25,0);
		buildGLCube(50); //start with the feet. Its right foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some design on that foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //more design for that foot
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(100,0,0); //equivalent to resetting, then going (30,25,-200)
		buildGLCube(50); //Its left foot
		glColor3f(0,0,0);
		glTranslatef(0,0,25.01);
		buildEquilateralTriangle(51); //do some more design, this time for the left foot
		glTranslatef(0,0,0.01);
		glColor3f(0.5,0,1);
		buildEquilateralTriangle(51); //still more design
		glTranslatef(0,0,-25.02);
		glColor3f(1,1,1);
		glTranslatef(-50, 150, 0); //for the torso: want x at 0 so 30-30, y at 150 so 25+75, z at same depth (for now)
		buildGLBrick(200,200,100); //the torso; should not be visible if clothes are on properly!
		glColor3f(0,1,0);
		buildGLBrick(200.1,100.01,100.1); //part of the shirt
		glColor3f(0.5,0.5,0.0);
		glTranslatef(0,-60,0);
		buildGLBrick(200.01,100.01,100.01); //part of the shorts
		glColor3f(0,0,0);
		glTranslatef(0,-40,0);
		buildGLBrick(10.01,50.01,100.02); //the crotch
		glTranslatef(0,100,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(-150,0,0); //put one arm out to the viewer's left by default
		buildGLBrick(40,50,40); //its right arm
		glTranslatef(300,0,0); //put the other arm out to the viewer's right by default
		buildGLBrick(40,50,40); //and its left arm
		glColor3f(0.5,0.5,0.5);
		glTranslatef(0,-60,0);
		buildGLBrick(60,100,5); //shell of the tablet
		glColor3f(0.4,0.4,0.4);
		buildGLBrick(55,90,5.1); //screen within the tablet
		glTranslatef(0,0,3);
		glScalef(0.5,0.5,0.5);
		buildFakeApple(); //Apple logo
		glScalef(2,2,2);
		glTranslatef(0,0,-3);
		glTranslatef(0,60,0);
		glTranslatef(-150,0,0);
		glTranslatef(0,50,0);
		glColor3f(0.5,0,0); //color of the T-shirt
		buildGLBrick(200.2,100,100.2); //T-shirt part: main body primary
		glTranslatef(0,10,0);
		buildGLBrick(280.2,65,95); //T-shirt part: main body shoulders
		glTranslatef(0,-10,0);
		glTranslatef(-150,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 1
		glTranslatef(300,0,0);
		buildGLBrick(50.01,75,50.01); //T-shirt: sleeve 2
		glTranslatef(-150,0,0);
		glColor3f((77.0/255),(38.0/255.0),0);
		glTranslatef(0,46,0);
		buildGLBrick(48,7,100.3); //the neck hole
		glTranslatef(0,90,0); //want the head just above the torso
		buildGLCube(100); //and the head
		glColor3f(.5,0,.5);
		glPushMatrix();
			glTranslatef(0,headphoneYAdditionToPosition,0);
			buildHeadphones();
		glPopMatrix();
		if (headphoneYAdditionToPosition >= 555)
		{
			glTranslatef(0,180,0);
			surfbort();
			glTranslatef(0,-180,0);
		}
	glPopMatrix();
}

// This function is called whenever the window size is changed
// OpenGL, in tandem with the OS, decide what to do, and provide the necessary params.
//@params: the new width and height of the display window, to assist with how to scale accordingly
//@return: [none]
void manageReshape (int w, int h)
{
	if (w < h)
	{
		glViewport (0, ((h - w) /2), (GLsizei) w, (GLsizei) w); // Set the viewport
	}
	else if (h < w)
	{
		glViewport (((w - h) /2), 0, (GLsizei) h, (GLsizei) h); // Set the viewport
	}
	else
	{
		glViewport (0, 0, (GLsizei) w, (GLsizei) h); // Set the viewport
	}
}

//called on normal key presses--for now, 0, 1
void manageNormalKeyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
		case '0' :
			currentScalingMagnitude += scaleChangeMagnitude;
		break;

		case '1' :
			if (currentScalingMagnitude - scaleChangeMagnitude < 1)
			{
				currentScalingMagnitude = 1;
			}
			else
			{
				currentScalingMagnitude -= scaleChangeMagnitude;
			}
		break;
	}
	glutPostRedisplay(); // Redraw the scene

}

// called on special key pressed
void manageArrowKeyInput(int key, int x, int y) { 

	// Check which key is pressed

	switch(key) {
		case GLUT_KEY_RIGHT : // Rotate counterclockwise
			if (currentTheta + thetaChangeMagnitude >= 360)
			{
				currentTheta = 0;
			}
			currentTheta += thetaChangeMagnitude;
		break;
		case GLUT_KEY_LEFT : // Rotate clockwise
			if (currentTheta - thetaChangeMagnitude <= 0)
			{
				currentTheta = 360;
			}
			currentTheta -= thetaChangeMagnitude;
		break;
		case GLUT_KEY_UP : // Move in the direction of the arrow
			headphoneYAdditionToPosition += 3.0;
			
		break;
		case GLUT_KEY_DOWN : // Move in the opposite direction of the arrow
			if (headphoneYAdditionToPosition - 1.0 > 0)
			{
				headphoneYAdditionToPosition -= 3.0;
			}
		break; 
	}
    glutPostRedisplay(); // Redraw the scene
}




void mouseFunction(int button, int state, int x, int y){
	switch(button) {
		case GLUT_LEFT_BUTTON : // Rotate counterclockwise
			if (state == GLUT_DOWN)
			{
				if (goingToRight) //start going to the left
				{
					goingToRight = false;
					goingToDefault = true;
					goingToLeft = false;

					//mouseLeftGTR();

					destinationXPosition -= destinationXChange;
					
				}
				else if (goingToLeft)
				{
					//mouseLeftGTL();

					destinationXPosition = destinationXPosition;
				}
				else if (goingToDefault) //keep going to the left
				{
					goingToLeft = true;
					goingToDefault = false;
					goingToRight = false;

					//mouseLeftGTD();

					destinationXPosition -= destinationXChange;
				}
			}
		break;
		case GLUT_RIGHT_BUTTON : // Rotate clockwise
			if (state == GLUT_DOWN)
			{
				if (goingToRight)
				{
					//no need to change the state, but keep moving as necessary

					//mouseRightGTR();

					destinationXPosition = destinationXPosition;
					
				}
				else if (goingToLeft) //start going right; you're probably past the default position, so go to default
				{
					goingToLeft = false;
					goingToDefault = true;
					goingToRight = false;

					//mouseRightGTL();

					destinationXPosition += destinationXChange;
				}
				else if (goingToDefault) //have it go all the way to the right
				{
					goingToLeft = false;
					goingToDefault = false;
					goingToRight = true;
					
					//mouseRightGTD();

					destinationXPosition += destinationXChange;
				}
			}
		break;
	}
    glutPostRedisplay(); // Redraw the scene

}

void myinit()
{
 
/* attributes */
      glClearColor(0.0, 0.0, 0.0, 1.0); /*black background */
      
/* set up viewing */
/* 500 x 500 window with origin lower left */
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      //glOrtho(0.0, 1200.0, 0.0, 1200.0, 0.0, 1200); //hopefully, this allows closer-to-pixel mapping as I draw the object
	  gluPerspective(145, 1, .1, 1000);
	  gluLookAt(500, 500, 10, /* look from camera XYZ */
               500, 500, 0, /* look at the origin */
               0, 1, 0); /* positive Y up vector */
      glMatrixMode(GL_MODELVIEW);
}

void display( void )
{
	
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  /*clear the window */
	//END SETUP; BEGIN DRAWING THINGS

	
	
	//Person-building code goes here!
	if (currentXPosition != destinationXPosition){

		while (currentXPosition != destinationXPosition)
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			//fake 3D cube logo in lower left
			glPushMatrix();
				glTranslatef(100,100,-300);
				glRotatef(45,0,1,0);
				glRotatef(45,1,0,0);
				buildFakeLogo(100);
			glPopMatrix();

			
			if (currentXPosition < destinationXPosition)
			{
				currentXPosition += deltaXPosition;
			}
			else if (currentXPosition > destinationXPosition)
			{
				currentXPosition -= deltaXPosition;
			}
			glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
				glTranslatef(currentXPosition,currentYPosition,-500);
				glRotatef(currentTheta,0,1,0);
				glScalef(currentScalingMagnitude,currentScalingMagnitude,currentScalingMagnitude);
				buildRudementaryPerson();

				
			glPopMatrix(); //...restore the state of the matrix after the person is called!
			glutSwapBuffers();
		}
	}
	else
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//fake 3D cube logo in lower left
		glPushMatrix();
			glTranslatef(100,100,-300);
			glRotatef(45,0,1,0);
			glRotatef(45,1,0,0);
			buildFakeLogo(100);
			
		glPopMatrix();

		

		glPushMatrix(); //because you don't want subsequent calls of RedrawPerson to be affected by the translation inside multiple times...
				glTranslatef(currentXPosition,currentYPosition,-500);
				glRotatef(currentTheta,0,1,0);
				glScalef(currentScalingMagnitude,currentScalingMagnitude,currentScalingMagnitude);
				buildRudementaryPerson();
		glPopMatrix(); //...restore the state of the matrix after the person is called!
		glutSwapBuffers();
	}


	//displayAnimatedArrows(); //this method is not called in assignment 2
	//displayAnimatedGrass();
	//drawPersonWithDirArrow(); //draw the person to be moved around

	//glutSwapBuffers();
	//glFlush();


 }


void main(int argc, char** argv)
{

/* Standard GLUT initialization */

    glutInit(&argc,argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); /*as set by default*/
    glutInitWindowSize(600,600); /* 500 x 500 window by default*/
    glutInitWindowPosition(0,0); /* place window top left on display */
    glutCreateWindow("COMP-5/6400 Assignment 3"); /* window title */
	
	glutReshapeFunc(manageReshape); //defines what method to call when the user resizes a window; target function is defined above
	glutKeyboardFunc(manageNormalKeyInput);
	glutSpecialFunc(manageArrowKeyInput); //tells the program to be waiting for input from arrow keys; target function is defined above
    glutDisplayFunc(display); /* display callback invoked when window opened */
	glutMouseFunc(mouseFunction);

		//mouseFunction(int button, int state, int x, int y){}

    myinit(); /* set attributes */
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
    glutMainLoop(); /* enter event loop */
}

//glClear call also has GL_DEPTH_BUFFER_BIT
//glOrtho() instead of glOrtho2D(), and be sure to set the bounds for the Z
//and add GLUT_DEPTH to the glutInitDisplayMode
//after glutDisplay and such 
// glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LESS); //not GL_EQUAL //put all this before glutMainLoop();