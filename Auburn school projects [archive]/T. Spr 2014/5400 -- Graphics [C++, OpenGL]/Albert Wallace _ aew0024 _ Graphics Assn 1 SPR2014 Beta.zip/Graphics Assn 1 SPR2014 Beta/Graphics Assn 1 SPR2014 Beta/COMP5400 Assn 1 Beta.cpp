
/*Auburn University Student Center, beta version       */
/*    (very low-res)                       */
/* Modified from the Two-Dimensional Sierpinski Gasket code        */
/*Albert Wallace, aew0024, 30 January 2014                        */

#include <stdlib.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <time.h>
#include <math.h>
#include <chrono>
#include <thread>

#define PI 3.141592653589739

void myinit()
{
 
/* attributes */

      glClearColor(1.0, 1.0, 1.0, 1.0); /* white background */
      glColor3f(1.0, 0.0, 0.7); /* draw in some sort of purple */

/* set up viewing */
/* 500 x 500 window with origin lower left */

      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluOrtho2D(0.0, 50.0, 0.0, 50.0);
      glMatrixMode(GL_MODELVIEW);
}

void display( void )
{
	std::chrono::milliseconds dura( 250 );
    

    int rand();       /* standard random number generator */
	float busyWait = 0;
	float idealBusyWait = 10000;

	float sbr = 2; //ratio by which to scale; best value to set depends on view window, etc; no forumla available
	float fshftX = 0*sbr; //value by which to shift the grass sprigs to the right, on top of the original value; change before drawing each sprig
	float fshftY = 0*sbr; //value by which to shift the grass sprigs up, on top of the original value; change before drawing each sprig
	float denomRGB = 255; //to convert from 8-bit representation to float representation
	float delta_theta = 0.001; //for drawing the pseudo-circle; controlls the overall smoothness by making smaller and smaller (or larger and larger) degree sweeps between vertices
	float angle = 0; //the starting angle for the circule
	float sbksshftX = 9.35;
	float sbksshftY = 19.6;
	int radius = 2.20;

	int entranceArrowLoopCount = 0; //used in the animation for the arrows; required as the variable in the "for" loop
	int arrowTimingPosition = 0; //range from 0 to 2 and back to 0; represents 3 positions where the arrows--the trangles --may be at a given step in the loop
	float xAnimPos = 0; //by how much we shift the arrows during animation, for arrows that point along the X axis; change this value & redraw to "animate"
	float yAnimPos = 0; //by how much we shift the arrows during animation, for arrows that point along the Y axis; change this value and redraw to "animate"
	int colorChoice = 0; //help decide between the color being beige or blue during animation

	int grassVisLoopCount = 0; //used in the animation for the grass sprigs; required as the variable in the "for" loop
	int grassColorChangeTiming = 0; //used to decide whether to display the first color combo or second color combo

    glClear(GL_COLOR_BUFFER_BIT);  /*clear the window */

	


	//first up, some general concourse work, including an entrance or two, as well as the tiger transit bus stop
	//each general part of the concourse will be made of two triangles, of two different colors
	//draw all of one color first, then draw all of the other color second
	glColor3f(92/denomRGB,8/denomRGB,8/denomRGB); //color for the first triangle in each concourse path: deep ruby/maroon

	//LEFT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,24*sbr);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(3*sbr,24*sbr);
	glEnd();

	//UPPER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,24*sbr);
		glVertex2f(12*sbr,20*sbr);
		glVertex2f(12*sbr,24*sbr);
	glEnd();

	//MIDDLE VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(14*sbr,26*sbr);
		glVertex2f(10*sbr,12*sbr);
		glVertex2f(14*sbr,12*sbr);
	glEnd();

	//MIDDLE HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(12*sbr,12*sbr);
		glVertex2f(27*sbr,12*sbr);
		glVertex2f(12*sbr,16*sbr);
	glEnd();

	//RIGHT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(19*sbr,0*sbr);
		glVertex2f(23*sbr,14*sbr);
		glVertex2f(19*sbr,14*sbr);
	glEnd();

	//LOWER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,0*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(0*sbr,4*sbr);
	glEnd();

	glColor3f(92/denomRGB,8/denomRGB,8/denomRGB); //color for the second triangle in each concourse path; same as first color unless otherwise specified

	//LEFT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(3*sbr,4*sbr);
		glVertex2f(3*sbr,24*sbr);
	glEnd();

	//UPPER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,20*sbr);
		glVertex2f(12*sbr,20*sbr);
		glVertex2f(0*sbr,24*sbr);
	glEnd();

	//MIDDLE VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(10*sbr,12*sbr);
		glVertex2f(14*sbr,26*sbr);
		glVertex2f(10*sbr,26*sbr);
	glEnd();

	//MIDDLE HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(12*sbr,16*sbr);
		glVertex2f(27*sbr,12*sbr);
		glVertex2f(27*sbr,16*sbr);
	glEnd();

	//RIGHT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(19*sbr,0*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(23*sbr,14*sbr);
	glEnd();

	//LOWER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(23*sbr,4*sbr);
	glEnd();

	glFlush();

	//tiger transit stop

	glColor3f(0/denomRGB,0/denomRGB,0/denomRGB); //color for the basic outline of the greenspace: green (brighter)

	glBegin(GL_QUADS);
			glVertex2f(11.45*sbr,0*sbr);
			glVertex2f(12.55*sbr,0*sbr);
			glVertex2f(12.55*sbr,3.25*sbr);
			glVertex2f(11.45*sbr,3.25*sbr);
	glEnd();

	glBegin(GL_QUADS);
			glVertex2f(7.45*sbr,0*sbr);
			glVertex2f(14.55*sbr,0*sbr);
			glVertex2f(14.55*sbr,0.5*sbr);
			glVertex2f(7.45*sbr,0.5*sbr);
	glEnd();

	//the greenspace

	//basic grass
	glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color for the basic outline of the greenspace: green (brighter)

	glBegin(GL_QUADS); //lower right
		glVertex2f(22.2*sbr,0*sbr);
		glVertex2f(30*sbr,0*sbr);
		glVertex2f(30*sbr,13*sbr);
		glVertex2f(22.2*sbr,13*sbr);
	glEnd();

	glBegin(GL_QUADS); //upper right
		glVertex2f(14*sbr,16*sbr);
		glVertex2f(30*sbr,16*sbr);
		glVertex2f(30*sbr,30*sbr);
		glVertex2f(14*sbr,30*sbr);
	glEnd();

	glBegin(GL_QUADS); //upper left
		glVertex2f(0*sbr,24*sbr);
		glVertex2f(10*sbr,24*sbr);
		glVertex2f(10*sbr,30*sbr);
		glVertex2f(0*sbr,30*sbr);
	glEnd();


	//a few sprigs of extra grass here and there
	glColor3f(0/denomRGB,51/denomRGB,0/denomRGB); //color for these sprigs of grass: green (darker)

	glBegin(GL_POLYGON);
		fshftX = 23*sbr;
		fshftY = 17*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 24*sbr;
		fshftY = 11*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 23*sbr;
		fshftY = 9*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 24*sbr;
		fshftY = 7*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();


	//and a new set of sprigs of grass with a different color
	glColor3f(0/denomRGB,81/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)

	glBegin(GL_POLYGON);
		fshftX = 21*sbr;
		fshftY = 19*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 17*sbr;
		fshftY = 19*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 6*sbr;
		fshftY = 24*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();

	glBegin(GL_POLYGON);
		fshftX = 4*sbr;
		fshftY = 24.5*sbr;
		glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
		glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
		glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
		glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
		glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
		glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
		glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
		glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
	glEnd();


	//basic outline of the student center itself
	glColor3f(161/denomRGB,161/denomRGB,161/denomRGB); //color for the basic outline of the SC: grey-ish

	glBegin(GL_POLYGON);
		glVertex2f(0*sbr,1*sbr);
		glVertex2f(5.75*sbr,1*sbr);
		glVertex2f(5.75*sbr,5*sbr);
		glVertex2f(0*sbr,5*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(5.75*sbr,2*sbr);
		glVertex2f(11*sbr,2*sbr);
		glVertex2f(11*sbr,3*sbr);
		glVertex2f(5.75*sbr,3*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(14*sbr,0*sbr);
		glVertex2f(17.75*sbr,0*sbr);
		glVertex2f(17.75*sbr,2.75*sbr);
		glVertex2f(14*sbr,2.75*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(17.75*sbr,2*sbr);
		glVertex2f(20.75*sbr,2*sbr);
		glVertex2f(20.75*sbr,10.75*sbr);
		glVertex2f(20.2*sbr,10.75*sbr);
		glVertex2f(20.2*sbr,12.5*sbr);
		glVertex2f(19.5*sbr,12.5*sbr);
		glVertex2f(19.5*sbr,13.5*sbr);
		glVertex2f(16*sbr,13.5*sbr);
		glVertex2f(16*sbr,14*sbr);
		glVertex2f(14.25*sbr,14*sbr);
		glVertex2f(14.25*sbr,12.5*sbr);
		glVertex2f(13.75*sbr,12.5*sbr);
		glVertex2f(13.75*sbr,13*sbr);
		glVertex2f(12*sbr,13*sbr);
		glVertex2f(12*sbr,12.75*sbr);
		glVertex2f(10.5*sbr,12.75*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(2.25*sbr,2.75*sbr);
		glVertex2f(18*sbr,2.75*sbr);
		glVertex2f(18*sbr,12.5*sbr);
		glVertex2f(2.75*sbr,12.5*sbr);
		glVertex2f(2.75*sbr,10.75*sbr);
		glVertex2f(2.25*sbr,10.75*sbr);
		glVertex2f(2.25*sbr,6.25*sbr);
	glEnd(); 


	
	glBegin(GL_POLYGON);
		glVertex2f(2.5*sbr,12.5*sbr);
		glVertex2f(10.25*sbr,12.5*sbr);
		glVertex2f(10.25*sbr,15*sbr);
		glVertex2f(10.50*sbr,15*sbr);
		glVertex2f(10.50*sbr,21*sbr);
		glVertex2f(4.25*sbr,21*sbr);
		glVertex2f(4.25*sbr,20.5*sbr);
		glVertex2f(2.5*sbr,20.5*sbr);
	glEnd();
	
	
	glBegin(GL_POLYGON); // our circle; code via the Internet; represents current-day Starbucks

		for(angle; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}

	glEnd();

	glFlush();

	//and to give a little shading to the student center building itself
	glColor3f(173/denomRGB,66/denomRGB,0/denomRGB); //color for the primary shading of the SC: brownish-orange


	
	//angle = 0; //must reset the angle in order to get the second drawing done
	glBegin(GL_POLYGON); // step one to shade the Starbucks circle
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();

	glBegin(GL_QUADS); //primary shade: upper/main left side of SC
		glVertex2f(3*sbr,6*sbr);
		glVertex2f(10*sbr,6*sbr);
		glVertex2f(10*sbr,20*sbr);
		glVertex2f(3*sbr,20*sbr);
	glEnd();

	glBegin(GL_QUADS); //primary shade: bottom-right side of SC
		glVertex2f(3*sbr,3.5*sbr);
		glVertex2f(19.75*sbr,3.5*sbr);
		glVertex2f(19.75*sbr,12*sbr);
		glVertex2f(3*sbr,12*sbr);
	glEnd();

	glBegin(GL_QUADS); //primary shade: lower-right side of SC
		glVertex2f(14.25*sbr,0.45*sbr);
		glVertex2f(17.60*sbr,0.45*sbr);
		glVertex2f(17.60*sbr,9.40*sbr);
		glVertex2f(14.25*sbr,9.40*sbr);
	glEnd();

	glBegin(GL_QUADS); //primary shade: lower left corner of SC
		glVertex2f(0.5*sbr,2*sbr);
		glVertex2f(5.25*sbr,2*sbr);
		glVertex2f(5.25*sbr,4.3*sbr);
		glVertex2f(0.5*sbr,4.3*sbr);
	glEnd();

	//and some secondary shading
	glColor3f(112/denomRGB,36/denomRGB,0/denomRGB); //color for the secondary shading of the SC: brownish-orange

	angle = 0;
	glBegin(GL_POLYGON); // adding a little more shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();

	glBegin(GL_QUADS); //secondary shade: upper/main left side of SC
		glVertex2f(3.25*sbr,6.25*sbr);
		glVertex2f(9.75*sbr,6.25*sbr);
		glVertex2f(9.75*sbr,19.75*sbr);
		glVertex2f(3.25*sbr,19.75*sbr);
	glEnd();

	glBegin(GL_QUADS); //secondary shade: middle-right side of SC
		glVertex2f(3.25*sbr,3.75*sbr);
		glVertex2f(19.5*sbr,3.75*sbr);
		glVertex2f(19.5*sbr,11.50*sbr);
		glVertex2f(3.25*sbr,11.50*sbr);
	glEnd();

	glBegin(GL_QUADS); //secondary shade: lower-right side of SC
		glVertex2f(14.40*sbr,0.65*sbr);
		glVertex2f(17.40*sbr,0.65*sbr);
		glVertex2f(17.40*sbr,9.40*sbr);
		glVertex2f(14.40*sbr,9.40*sbr);
	glEnd();

	glBegin(GL_QUADS); //secondary shade: lower left corner of SC
		glVertex2f(0.65*sbr,2.2*sbr);
		glVertex2f(5.1*sbr,2.20*sbr);
		glVertex2f(5.1*sbr,3.75*sbr);
		glVertex2f(0.65*sbr,3.75*sbr);
	glEnd();

	//and tertiary shading?

	glColor3f(255/denomRGB,168/denomRGB,69/denomRGB); //color for the tertiary shading of the SC: brownish-orange

	angle = 0;

	glBegin(GL_POLYGON); // adding a final touch of shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();

	glBegin(GL_QUADS); //tertiary shade: upper/main left side of SC
		glVertex2f(3.35*sbr,6.3*sbr);
		glVertex2f(9.7*sbr,6.3*sbr);
		glVertex2f(9.7*sbr,19.7*sbr);
		glVertex2f(3.35*sbr,19.7*sbr);
	glEnd();

	glBegin(GL_QUADS); //tertiary shade: middle-right side of SC
		glVertex2f(3.35*sbr,3.85*sbr);
		glVertex2f(19.3*sbr,3.85*sbr);
		glVertex2f(19.3*sbr,11.40*sbr);
		glVertex2f(3.35*sbr,11.40*sbr);
	glEnd();

	glBegin(GL_QUADS); //tertiary shade: lower-right side of SC
		glVertex2f(14.5*sbr,0.75*sbr);
		glVertex2f(17.3*sbr,0.75*sbr);
		glVertex2f(17.3*sbr,9.40*sbr);
		glVertex2f(14.5*sbr,9.40*sbr);
	glEnd();


	glBegin(GL_QUADS); //tertiary shade: lower left corner of SC
		glVertex2f(0.85*sbr,2.35*sbr);
		glVertex2f(5*sbr,2.35*sbr);
		glVertex2f(5*sbr,3.9*sbr);
		glVertex2f(0.85*sbr,3.9*sbr);
	glEnd();

	glColor3f(255/denomRGB,217/denomRGB,173/denomRGB); //color for the quarternary shading of the SC: brownish-orange

	angle = 0;

	glBegin(GL_POLYGON); // adding a super final touch of shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();

	glBegin(GL_QUADS); //4th shade: upper/main left side of SC
		glVertex2f(3.65*sbr,7.1*sbr);
		glVertex2f(8.7*sbr,7.1*sbr);
		glVertex2f(8.7*sbr,18.9*sbr);
		glVertex2f(3.65*sbr,18.9*sbr);
	glEnd();

	glBegin(GL_QUADS); //4th shade: middle-right side of SC
		glVertex2f(3.65*sbr,4.05*sbr);
		glVertex2f(19*sbr,4.05*sbr);
		glVertex2f(19*sbr,11*sbr);
		glVertex2f(3.65*sbr,11*sbr);
	glEnd();

	glBegin(GL_QUADS); //4th shade: lower-right side of SC
		glVertex2f(15*sbr,1.75*sbr);
		glVertex2f(17*sbr,1.75*sbr);
		glVertex2f(17*sbr,9*sbr);
		glVertex2f(15*sbr,9*sbr);
	glEnd();


	glBegin(GL_QUADS); //4th shade: lower left corner of SC
		glVertex2f(1.85*sbr,2.75*sbr);
		glVertex2f(4*sbr,2.75*sbr);
		glVertex2f(4*sbr,3.5*sbr);
		glVertex2f(1.85*sbr,3.5*sbr);
	glEnd();


	for (entranceArrowLoopCount = 0; entranceArrowLoopCount < 10000; entranceArrowLoopCount++)
	{
		//now that walking surfaces are done, how about the entrances/exits?
		//glColor3f(28/denomRGB,150/denomRGB,212/denomRGB); //color for the entrances/exits; blue
		
		if (entranceArrowLoopCount%200 == 0)
		{
			if (arrowTimingPosition == 0)
			{
				xAnimPos = 0;
				yAnimPos = 0;

			}
			else if (arrowTimingPosition == 1)
			{
				xAnimPos = .5;
				yAnimPos = .5;
			}
			else
			{
				xAnimPos = 1;
				yAnimPos = 1;
				arrowTimingPosition = -1;
				if (colorChoice == 0) //then switch to another color choice before rendering the rest of the arrows
				{
					glColor3f(255/denomRGB,217/denomRGB,173/denomRGB); //color for the entrances/exits; beige
					colorChoice = 1;
				}
				else //then switch back to the primary color choice before re-rendering the arrows
				{
					glColor3f(28/denomRGB,150/denomRGB,212/denomRGB); //color for the entrances/exits; blue
					colorChoice = 0;
				}
			}
			arrowTimingPosition++;
		}
		glBegin(GL_TRIANGLES);
			glVertex2f((2.5-xAnimPos)*sbr,11.5*sbr);
			glVertex2f((3-xAnimPos)*sbr,12*sbr);
			glVertex2f((2.5-xAnimPos)*sbr,12.5*sbr);
		glEnd();


		glBegin(GL_TRIANGLES);
			glVertex2f(11.75*sbr,(2.75-yAnimPos)*sbr);
			glVertex2f(12.25*sbr,(2.75-yAnimPos)*sbr);
			glVertex2f(12*sbr,(3.25-yAnimPos)*sbr);
		glEnd();


		glBegin(GL_TRIANGLES);
			glVertex2f(18.5*sbr,(2-yAnimPos)*sbr);
			glVertex2f(19.5*sbr,(2-yAnimPos)*sbr);
			glVertex2f(19*sbr,(2.5-yAnimPos)*sbr);
		glEnd();


		glBegin(GL_TRIANGLES); //right trio bottom
			glVertex2f((19.75+xAnimPos)*sbr,3*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,2.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,3.5*sbr);
		glEnd();


		glBegin(GL_TRIANGLES); //right trio middle
			glVertex2f((19.75+xAnimPos)*sbr,6*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,5.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,6.5*sbr);

		glBegin(GL_TRIANGLES); //right trio top
			glVertex2f((19.75+xAnimPos)*sbr,9*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,8.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,9.5*sbr);
		glEnd();

		glFlush();

		glBegin(GL_QUADS); //right corner stairs to CFA
			glVertex2f(20.2*sbr,10.55*sbr);
			glVertex2f(20.6*sbr,10.55*sbr);
			glVertex2f(20.6*sbr,12.5*sbr);
			glVertex2f(20.2*sbr,12.5*sbr);
		glEnd();


		glBegin(GL_TRIANGLES); //tiny entrance into ABP
			glVertex2f(19.55*sbr,(12.5+yAnimPos)*sbr);
			glVertex2f(19.7*sbr,(12.1+yAnimPos)*sbr);
			glVertex2f(19.85*sbr,(12.5+yAnimPos)*sbr);
		glEnd();


		glBegin(GL_TRIANGLES);
			glVertex2f(18*sbr,(13.5+yAnimPos)*sbr);
			glVertex2f(18.5*sbr,(12.5+yAnimPos)*sbr);
			glVertex2f(19*sbr,(13.5+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //help desk entrance
			glVertex2f(12.25*sbr,(13+yAnimPos)*sbr);
			glVertex2f(12.5*sbr,(12+yAnimPos)*sbr);
			glVertex2f(12.75*sbr,(13+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //near Starbucks, side, lower
			glVertex2f((10.45+xAnimPos)*sbr,15.75*sbr);
			glVertex2f((10+xAnimPos)*sbr,15.5*sbr);
			glVertex2f((10.45+xAnimPos)*sbr,15.25*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //near Starbucks, side, upper
			glVertex2f((11.25+xAnimPos)*sbr,20*sbr);
			glVertex2f((10.5+xAnimPos)*sbr,19.5*sbr);
			glVertex2f((11.25+xAnimPos)*sbr,19*sbr);
		glEnd();

	
		glBegin(GL_TRIANGLES); //topmost middle, near Starbucks
			glVertex2f(9*sbr,(21.5+yAnimPos)*sbr);
			glVertex2f(9.5*sbr,(20.5+yAnimPos)*sbr);
			glVertex2f(10*sbr,(21.5+yAnimPos)*sbr);
		glEnd();


		glBegin(GL_TRIANGLES); //topmost left
			glVertex2f(6*sbr,(21+yAnimPos)*sbr);
			glVertex2f(6.5*sbr,(20+yAnimPos)*sbr);
			glVertex2f(7*sbr,(21+yAnimPos)*sbr);
		glEnd();

		glFlush();
	}

	for (grassVisLoopCount = 0; grassVisLoopCount < 100; grassVisLoopCount++) //let's animate the grass!
	{
		glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color to reset the opposing grass: green (brighter)

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 17*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 11*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 9*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 7*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 21*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 17*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 6*sbr;
			fshftY = 24*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 4*sbr;
			fshftY = 24.5*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glFlush();
		//this is where the list restarts, so these values should be equivalent to the original sprigs of grass, including colors

		//a few sprigs of extra grass here and there
		glColor3f(0/denomRGB,51/denomRGB,0/denomRGB); //color for these sprigs of grass: green (darker)

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 17*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 11*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 9*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 7*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();


		//and a new set of sprigs of grass with a different color
		glColor3f(0/denomRGB,81/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)

		glBegin(GL_POLYGON);
			fshftX = 21*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 17*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 6*sbr;
			fshftY = 24*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 4*sbr;
			fshftY = 24.5*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glFlush();

			

		std::this_thread::sleep_for( dura );

		glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color to reset the opposing grass: green (brighter)

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 17*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 11*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 9*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 7*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();


		//and a new set of sprigs of grass with a different color
		glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)

		glBegin(GL_POLYGON);
			fshftX = 21*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 17*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 6*sbr;
			fshftY = 24*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 4*sbr;
			fshftY = 24.5*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.5*sbr)+fshftY);
		glEnd();
		//and then the alternates take over, color-wise_____________________________________

		//and a new set of sprigs of grass with a different color
		glColor3f(0/denomRGB,81/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 17*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 11*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 23*sbr;
			fshftY = 9*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 24*sbr;
			fshftY = 7*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();


		//a few sprigs of extra grass here and there
		glColor3f(0/denomRGB,51/denomRGB,0/denomRGB); //color for these sprigs of grass: green (darker)

		glBegin(GL_POLYGON);
			fshftX = 21*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 17*sbr;
			fshftY = 19*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 6*sbr;
			fshftY = 24*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glBegin(GL_POLYGON);
			fshftX = 4*sbr;
			fshftY = 24.5*sbr;
			glVertex2f((0.2*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0*sbr)+fshftY);
			glVertex2f((0.9*sbr)+fshftX,(0.5*sbr)+fshftY);
			glVertex2f((0.8*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.7*sbr)+fshftX,(0.8*sbr)+fshftY);
			glVertex2f((0.6*sbr)+fshftX,(0.3*sbr)+fshftY);
			glVertex2f((0.5*sbr)+fshftX,(0.7*sbr)+fshftY);
			glVertex2f((0.4*sbr)+fshftX,(0.2*sbr)+fshftY);
			glVertex2f((0.3*sbr)+fshftX,(0.6*sbr)+fshftY);
			glVertex2f((0.2*sbr)+fshftX,(0.1*sbr)+fshftY);
			glVertex2f((0.1*sbr)+fshftX,(0.3*sbr)+fshftY);
		glEnd();

		glFlush();

		std::this_thread::sleep_for( dura );

	}

 }

void main(int argc, char** argv)
{

/* Standard GLUT initialization */

    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB); /* default, not needed */
    glutInitWindowSize(640,480); /* 500 x 500 pixel window, except not really */
    glutInitWindowPosition(0,0); /* place window top left on display */
    glutCreateWindow("COMP-5/6400 Assignment 1"); /* window title */
    glutDisplayFunc(display); /* display callback invoked when window opened */

    myinit(); /* set attributes */

    glutMainLoop(); /* enter event loop */
}

