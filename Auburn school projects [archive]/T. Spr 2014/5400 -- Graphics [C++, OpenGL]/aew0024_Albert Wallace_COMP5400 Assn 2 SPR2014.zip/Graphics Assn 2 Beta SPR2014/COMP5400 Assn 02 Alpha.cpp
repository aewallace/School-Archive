
/*Auburn University Student Center, plus mobile person. */
/*	COMP5400 Assignment #02, version alpha       */
/*    (very low-res)                       */
/* Modified from the Two-Dimensional Sierpinski Gasket code        */
/*Albert Wallace, aew0024, 07, 13, 14 February 2014                        */
/*major code assistance provided by http://www.codeproject.com/Articles/23666/OpenGL-3D-Navigation-glRotatef-glTranslatef-gluLoo */
/*secondary code assistance noted elsewhere in the code itself*/

//to control man: direction is controlled by left and right arrows
//magnitude of movement is controlled by up (positive) or down (negative)
//the arrow points in the positive direction at all times
//...the arrow also looks like a flame
//....or a unicorn horn
//....anyway, to make the student's blocky face bigger or smaller,
// use the '0' key (to increase the size) or '1' key (to decrease the size)
//the student will move freely around the map, and will een move off the map (at least, in Visual Studio 2012)


#include <stdlib.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <time.h>
#include <math.h>
//#include <chrono> //used for better, more advanced animations
#include <thread>

#define PI 3.141592653589739

float sbr = 2; //ratio by which to scale; best value to set depends on view window, etc; no forumla available
float denomRGB = 255; //to convert from 8-bit representation to float representation
float thetaChangeMagnitude = 1.25f; //used to decide how much a person rotates, in degrees, upon each arrow press

GLfloat thetaToRotatePerson = 0.0f; // Translate screen to x direction (left or right); original value is almost meaningless as far as initial movement before use of left & right arrows
GLfloat currentXCoordinate = 1.0*sbr; //current X coordinate of the center of the face and arrow; original value defines the starting point
GLfloat currentYCoordinate = 1.0*sbr; //current Y coordinate of the center of the face and arrow; original value defines the starting point
GLfloat faceScaleFactor = 1.0; //how to scale the face by default
GLfloat riseY = 0.0f; //dictates how far to move along the Y axis, whether positive or negative; original value defines initial movement with up & down arrows
GLfloat runX = 2.0f; //dictates how far to move along the X axis, whether positive or negative; original value defines initial movement with up and down arrows
bool xAddWithLeftArrowKey = false; //used to aide with state-based rotation of the person's face
bool xAddWithRightArrowKey = true; //used to aide with state-based rotation of the person's face
bool yAddWithLeftArrowKey = false; //used to aide with state-based rotation of the person's face
bool yAddWithRightArrowKey = false; //used to aide with state-based rotation of the person's face


void buildGLRectangle(float xMin, float xMax, float yMin, float yMax) //used to speed up the creation of a GL QUAD that will only be a rectangle or square
{
	glBegin(GL_QUADS); 
		glVertex2f(xMin*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMin*sbr);
		glVertex2f(xMax*sbr,yMax*sbr);
		glVertex2f(xMin*sbr,yMax*sbr);
	glEnd();
}

void drawPersonWithDirArrow()
{
	glShadeModel(GL_SMOOTH);
	glPushMatrix();
	//drawing the arrow to guide the user
	glTranslatef(currentXCoordinate,currentYCoordinate,0.0f);
	glRotatef(((-1*thetaToRotatePerson)-90),0,0,1);
	glScalef(faceScaleFactor,faceScaleFactor,0);
	glBegin(GL_POLYGON); //begin drawing the outside of the arrow; each vertex can have its own color
		glColor3f(40/denomRGB,1/denomRGB,21/denomRGB); 
		glVertex2f(-0.4*sbr,0);
		glColor3f(212/denomRGB,150/denomRGB,255/denomRGB);
		glVertex2f(0.4*sbr,0);
		glColor3f(208/denomRGB,255/denomRGB,208/denomRGB);
		glVertex2f(0.4*sbr,0.5*sbr);
		glColor3f(212/denomRGB,0/denomRGB,212/denomRGB);
		glVertex2f(0,2.15*sbr);
		glColor3f(250/denomRGB,240/denomRGB,240/denomRGB);
		glVertex2f(-0.4*sbr,0.5*sbr);
	glEnd();
	glBegin(GL_POLYGON); //begin drawing the inside of the arrow for shading; each vertex can have its own color
		glColor3f(255/denomRGB,15/denomRGB,21/denomRGB); 
		glVertex2f(-0.1*sbr,0);
		glColor3f(28/denomRGB,15/denomRGB,0/denomRGB);
		glVertex2f(0.1*sbr,0);
		glColor3f(28/denomRGB,15/denomRGB,240/denomRGB);
		glVertex2f(0.1*sbr,0.5*sbr);
		glColor3f(156/denomRGB,0/denomRGB,156/denomRGB);
		glVertex2f(0,1.75*sbr);
		glColor3f(255/denomRGB,15/denomRGB,0/denomRGB);
		glVertex2f(-0.1*sbr,0.5*sbr);
	glEnd();
	glPopMatrix();

	//now for the face & features of the face
	glPushMatrix();
	glColor3f(107/denomRGB,57/denomRGB,0/denomRGB);
	glTranslatef(currentXCoordinate,currentYCoordinate,0.0f); //put the head in the right position
	glScalef(faceScaleFactor,faceScaleFactor,0);
	buildGLRectangle(-0.5*sbr, 0.5*sbr, -0.5*sbr, 0.5*sbr); //draw the head/face background as a square
		//and features
		glColor3f(0,0,0); //make the eyes black
		buildGLRectangle(-0.45*sbr,-0.33*sbr,0.30*sbr,0.35*sbr); //left eye
		buildGLRectangle(0.33*sbr,0.45*sbr,0.30*sbr,0.35*sbr); //right eye
		buildGLRectangle(-0.40*sbr,0.40*sbr,-0.05*sbr,0.013*sbr); //mouth box
		glColor3f(1,1,1); //color of snaggle tooth
		buildGLRectangle(0*sbr,0.10*sbr,-0.10*sbr,-0.05*sbr); //mouth box

	glPopMatrix();
}


void displayAnimatedArrows()
{

	int entranceArrowLoopCount = 0; //used in the animation for the arrows; required as the variable in the "for" loop
	int arrowTimingPosition = 0; //range from 0 to 2 and back to 0; represents 3 positions where the arrows--the trangles --may be at a given step in the loop
	float xAnimPos = 0; //by how much we shift the arrows during animation, for arrows that point along the X axis; change this value & redraw to "animate"
	float yAnimPos = 0; //by how much we shift the arrows during animation, for arrows that point along the Y axis; change this value and redraw to "animate"
	int colorChoice = 0; //help decide between the color being beige or blue during arrow animation
	
	//this provides rudimentary animation for the arrows and rectangle representing the entrances/exits
	for (entranceArrowLoopCount = 0; entranceArrowLoopCount < 10000; entranceArrowLoopCount++)
	{
		//now that walking surfaces are done, how about the entrances/exits?
		//glColor3f(28/denomRGB,150/denomRGB,212/denomRGB); //color for the entrances/exits; blue
		
		if (entranceArrowLoopCount%200 == 0)
		{
			if (arrowTimingPosition == 0)
			{
				xAnimPos = 0;
				yAnimPos = 0;

			}
			else if (arrowTimingPosition == 1)
			{
				xAnimPos = .5;
				yAnimPos = .5;
			}
			else
			{
				xAnimPos = 1;
				yAnimPos = 1;
				arrowTimingPosition = -1;
				if (colorChoice == 0) //then switch to another color choice before rendering the rest of the arrows
				{
					glColor3f(255/denomRGB,217/denomRGB,173/denomRGB); //color for the entrances/exits; beige
					colorChoice = 1;
				}
				else //then switch back to the primary color choice before re-rendering the arrows
				{
					glColor3f(28/denomRGB,150/denomRGB,212/denomRGB); //color for the entrances/exits; blue
					colorChoice = 0;
				}
			}
			arrowTimingPosition++;
		}
		glBegin(GL_TRIANGLES);
			glVertex2f((2.5-xAnimPos)*sbr,11.5*sbr);
			glVertex2f((3-xAnimPos)*sbr,12*sbr);
			glVertex2f((2.5-xAnimPos)*sbr,12.5*sbr);
		glEnd();

		glBegin(GL_TRIANGLES);
			glVertex2f(11.75*sbr,(2.75-yAnimPos)*sbr);
			glVertex2f(12.25*sbr,(2.75-yAnimPos)*sbr);
			glVertex2f(12*sbr,(3.25-yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES);
			glVertex2f(18.5*sbr,(2-yAnimPos)*sbr);
			glVertex2f(19.5*sbr,(2-yAnimPos)*sbr);
			glVertex2f(19*sbr,(2.5-yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //right trio bottom
			glVertex2f((19.75+xAnimPos)*sbr,3*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,2.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,3.5*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //right trio middle
			glVertex2f((19.75+xAnimPos)*sbr,6*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,5.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,6.5*sbr);

		glBegin(GL_TRIANGLES); //right trio top
			glVertex2f((19.75+xAnimPos)*sbr,9*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,8.5*sbr);
			glVertex2f((20.75+xAnimPos)*sbr,9.5*sbr);
		glEnd();

		glFlush();

		glBegin(GL_QUADS); //right corner stairs to CFA
			glVertex2f(20.2*sbr,10.55*sbr);
			glVertex2f(20.6*sbr,10.55*sbr);
			glVertex2f(20.6*sbr,12.5*sbr);
			glVertex2f(20.2*sbr,12.5*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //tiny entrance into ABP
			glVertex2f(19.55*sbr,(12.5+yAnimPos)*sbr);
			glVertex2f(19.7*sbr,(12.1+yAnimPos)*sbr);
			glVertex2f(19.85*sbr,(12.5+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES);
			glVertex2f(18*sbr,(13.5+yAnimPos)*sbr);
			glVertex2f(18.5*sbr,(12.5+yAnimPos)*sbr);
			glVertex2f(19*sbr,(13.5+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //help desk entrance
			glVertex2f(12.25*sbr,(13+yAnimPos)*sbr);
			glVertex2f(12.5*sbr,(12+yAnimPos)*sbr);
			glVertex2f(12.75*sbr,(13+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //near Starbucks, side, lower
			glVertex2f((10.45+xAnimPos)*sbr,15.75*sbr);
			glVertex2f((10+xAnimPos)*sbr,15.5*sbr);
			glVertex2f((10.45+xAnimPos)*sbr,15.25*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //near Starbucks, side, upper
			glVertex2f((11.25+xAnimPos)*sbr,20*sbr);
			glVertex2f((10.5+xAnimPos)*sbr,19.5*sbr);
			glVertex2f((11.25+xAnimPos)*sbr,19*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //topmost middle, near Starbucks
			glVertex2f(9*sbr,(21.5+yAnimPos)*sbr);
			glVertex2f(9.5*sbr,(20.5+yAnimPos)*sbr);
			glVertex2f(10*sbr,(21.5+yAnimPos)*sbr);
		glEnd();

		glBegin(GL_TRIANGLES); //topmost left
			glVertex2f(6*sbr,(21+yAnimPos)*sbr);
			glVertex2f(6.5*sbr,(20+yAnimPos)*sbr);
			glVertex2f(7*sbr,(21+yAnimPos)*sbr);
		glEnd();

		glFlush();
	}
}


void buildGrassSprigTypeAlt(float fXShiftMultiplier, float fYShiftMultiplier)
{
	glBegin(GL_POLYGON);
			float fXShift = fXShiftMultiplier*sbr;
			float fYShift = fYShiftMultiplier*sbr;
			glVertex2f((0.2*sbr)+fXShift,(0*sbr)+fYShift);
			glVertex2f((0.8*sbr)+fXShift,(0*sbr)+fYShift);
			glVertex2f((0.9*sbr)+fXShift,(0.5*sbr)+fYShift);
			glVertex2f((0.8*sbr)+fXShift,(0.1*sbr)+fYShift);
			glVertex2f((0.7*sbr)+fXShift,(0.8*sbr)+fYShift);
			glVertex2f((0.6*sbr)+fXShift,(0.3*sbr)+fYShift);
			glVertex2f((0.5*sbr)+fXShift,(0.7*sbr)+fYShift);
			glVertex2f((0.4*sbr)+fXShift,(0.2*sbr)+fYShift);
			glVertex2f((0.3*sbr)+fXShift,(0.6*sbr)+fYShift);
			glVertex2f((0.2*sbr)+fXShift,(0.1*sbr)+fYShift);
			glVertex2f((0.1*sbr)+fXShift,(0.3*sbr)+fYShift);
	glEnd();
}

void buildGrassSprigTypeMain(float fXShiftMultiplier, float fYShiftMultiplier)
{
	glBegin(GL_POLYGON);
			float fXShift = fXShiftMultiplier*sbr;
			float fYShift = fYShiftMultiplier*sbr;
			glVertex2f((0.2*sbr)+fXShift,(0*sbr)+fYShift);
			glVertex2f((0.8*sbr)+fXShift,(0*sbr)+fYShift);
			glVertex2f((0.9*sbr)+fXShift,(0.3*sbr)+fYShift);
			glVertex2f((0.8*sbr)+fXShift,(0.1*sbr)+fYShift);
			glVertex2f((0.7*sbr)+fXShift,(0.5*sbr)+fYShift);
			glVertex2f((0.6*sbr)+fXShift,(0.2*sbr)+fYShift);
			glVertex2f((0.5*sbr)+fXShift,(0.7*sbr)+fYShift);
			glVertex2f((0.4*sbr)+fXShift,(0.3*sbr)+fYShift);
			glVertex2f((0.3*sbr)+fXShift,(0.6*sbr)+fYShift);
			glVertex2f((0.2*sbr)+fXShift,(0.1*sbr)+fYShift);
			glVertex2f((0.1*sbr)+fXShift,(0.5*sbr)+fYShift);
	glEnd();
}


void displayAnimatedGrass()
{
	int grassVisLoopCount = 0; //used in the animation for the grass sprigs; required as the variable in the "for" loop
	int grassColorChangeTiming = 0; //used to decide whether to display the first color combo or second color combo
	//std::chrono::milliseconds dura( 250 );

	glPushMatrix(); //this is us saving the original state of the transformation matrix
	glTranslatef(-15.0*sbr, -15.0*sbr, 0.0f);
	glScalef(1.05f,1.05f,0.0f);
	glTranslatef(13.0*sbr,13.0*sbr,0.0f);

	//basic grass background
	glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color for the basic outline of the greenspace: green (brighter)
	buildGLRectangle(22.2,30,0,13); //lower right
	buildGLRectangle(14,30,16,30); //upper right
	glPushMatrix(); //prepare to scale upper left
	glTranslatef(-2*sbr,-27*sbr,0); //continue to prepare for scaling
	glScalef(1.20f,1.05f,1.0f); //make matrix set for scaling upper left
	glTranslatef(2*sbr,24*sbr,0); //undo prior necessary translate
	buildGLRectangle(0,10,24,30); //draw upper left with associated scaling
	glPopMatrix(); //return to prior transformation

	for (grassVisLoopCount = 0; grassVisLoopCount < 100; grassVisLoopCount++) //let's animate the grass!
	{
		glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color to reset the opposing grass: green (brighter; generic background)
		buildGrassSprigTypeAlt(23,17);
		buildGrassSprigTypeAlt(24,11);
		buildGrassSprigTypeAlt(23,9);
		buildGrassSprigTypeAlt(24,7);
		buildGrassSprigTypeAlt(21,19);
		buildGrassSprigTypeAlt(17,19);
		buildGrassSprigTypeAlt(6,24);
		buildGrassSprigTypeAlt(4,24.5);
		//this is where the list restarts, so these values should be equivalent to the original sprigs of grass, including colors

		//a few sprigs of extra grass here and there
		glColor3f(0/denomRGB,51/denomRGB,0/denomRGB); //color for these sprigs of grass: green (darker)
		buildGrassSprigTypeMain(23,17);
		buildGrassSprigTypeMain(24,11);
		buildGrassSprigTypeMain(23,9);
		buildGrassSprigTypeMain(24,7);

		//and a new set of sprigs of grass with a different color
		glColor3f(0/denomRGB,81/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)
		buildGrassSprigTypeMain(21,19);
		buildGrassSprigTypeMain(17,19);
		buildGrassSprigTypeMain(6,24);
		buildGrassSprigTypeMain(4,24.5);
			
		//pause with this first frame for some set number of milliseconds, then resume with the second frame of the animation
		//std::this_thread::sleep_for( dura );

		glColor3f(0/denomRGB,123/denomRGB,0/denomRGB); //color to hide the main grass: green [brighter; generic background]
		buildGrassSprigTypeMain(23,17);
		buildGrassSprigTypeMain(24,11);
		buildGrassSprigTypeMain(23,9);
		buildGrassSprigTypeMain(24,7);
		buildGrassSprigTypeMain(21,19);
		buildGrassSprigTypeMain(17,19);
		buildGrassSprigTypeMain(6,24);
		buildGrassSprigTypeMain(4,24.5);
		//and then the alternates take over, color-wise_____________________________________

		//and a new set of sprigs of grass with a different color
		glColor3f(0/denomRGB,81/denomRGB,0/denomRGB); //color for these sprigs of grass: green (middle)
		buildGrassSprigTypeAlt(23,17);
		buildGrassSprigTypeAlt(24,11);
		buildGrassSprigTypeAlt(23,9);
		buildGrassSprigTypeAlt(24,7);

		//a few sprigs of extra grass here and there
		glColor3f(0/denomRGB,51/denomRGB,0/denomRGB); //color for these sprigs of grass: green (darker)
		buildGrassSprigTypeAlt(21,19);
		buildGrassSprigTypeAlt(17,19);
		glPushMatrix();
		glTranslatef(1.0f,2.0f,0);
		buildGrassSprigTypeAlt(17,19);
		glTranslatef(2.0f,-4.0f,0);
		buildGrassSprigTypeAlt(17,19);
		glPopMatrix();
		buildGrassSprigTypeAlt(6,24);
		buildGrassSprigTypeAlt(4, 24.5);
		glPushMatrix();
		glTranslatef(1.0f,1.0f,0);
		buildGrassSprigTypeAlt(4,24.5);
		glTranslatef(1.0f,1.0f,0);
		buildGrassSprigTypeAlt(4,24.5);
		glPopMatrix();

		glPushMatrix();
		glScalef(1.40f,1.40f,0.0f);
		glTranslatef(15*sbr,15*sbr,0.0f);
		buildGrassSprigTypeAlt(0,0);
		glPopMatrix();

		//std::this_thread::sleep_for( dura );
		glPopMatrix(); //recover the original transformation matrix pushed very early in the process
	}
}

// This function is called whenever the window size is changed
// OpenGL, in tandem with the OS, decide what to do, and provide the necessary params.
//@params: the new width and height of the display window, to assist with how to scale accordingly
//@return: [none]
void manageReshape (int w, int h)
{
	if (w < h)
	{
		glViewport (0, ((h - w) /2), (GLsizei) w, (GLsizei) w); // Set the viewport
	}
	else if (h < w)
	{
		glViewport (((w - h) /2), 0, (GLsizei) h, (GLsizei) h); // Set the viewport
	}
	else
	{
		glViewport (0, 0, (GLsizei) w, (GLsizei) h); // Set the viewport
	}
}

//called on normal key presses--for now, 0, 1
void manageNormalKeyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
		case '0' :
			faceScaleFactor += 0.1;
		break;

		case '1' :
			faceScaleFactor -= 0.1;
		break;
	}
	glutPostRedisplay(); // Redraw the scene

}

// called on special key pressed
void manageArrowKeyInput(int key, int x, int y) { 

	// Check which key is pressed

	switch(key) {
		case GLUT_KEY_RIGHT : // Rotate arrow counterclockwise
			thetaToRotatePerson += thetaChangeMagnitude;
			if (thetaToRotatePerson >= 360)
			{
				thetaToRotatePerson -= 360;
			}
			runX = cosf(thetaToRotatePerson * PI / 180);
			riseY = -1 * sinf(thetaToRotatePerson * PI / 180);
		break;
		case GLUT_KEY_LEFT : // Rotate arrow clockwise
			thetaToRotatePerson -= thetaChangeMagnitude;
			if (thetaToRotatePerson < 0)
			{
				thetaToRotatePerson += 360;
			}
			runX = cosf(thetaToRotatePerson * PI / 180);
			riseY = -1 * sinf(thetaToRotatePerson * PI / 180);
		break;
		case GLUT_KEY_UP : // Move in the direction of the arrow
			/*//distanceToMovePerson += 1.1f;
			flagLocomotePerson = true;*/
			currentXCoordinate += runX;
			currentYCoordinate += riseY;

		break;
		case GLUT_KEY_DOWN : // Move in the opposite direction of the arrow
			/*//distanceToMovePerson -= 1.1f;
			flagLocomotePerson = true;*/
			currentXCoordinate -= runX;
			currentYCoordinate -= riseY;
		break; 
	}
    glutPostRedisplay(); // Redraw the scene
}

void myinit()
{
 
/* attributes */
      glClearColor(0.0, 0.0, 0.0, 1.0); /* white background */
      glColor3f(1.0, 0.0, 0.7); /* draw in some sort of purple */
	  //glShadeModel(GL_SMOOTH);
/* set up viewing */
/* 500 x 500 window with origin lower left */
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluOrtho2D(0.0, 50.0, 0.0, 50.0);
      glMatrixMode(GL_MODELVIEW);
}

void display( void )
{
	std::chrono::milliseconds dura( 250 );
    
    int rand();       /* standard random number generator */
	float busyWait = 0;
	float idealBusyWait = 10000;

	float sbr = 2; //ratio by which to scale; best value to set depends on view window, etc; no forumla available
	float fXShift = 0*sbr; //value by which to shift the grass sprigs to the right, on top of the original value; change before drawing each sprig
	float fYShift = 0*sbr; //value by which to shift the grass sprigs up, on top of the original value; change before drawing each sprig
	
	float delta_theta = 0.001; //for drawing the pseudo-circle; controlls the overall smoothness by making smaller and smaller (or larger and larger) degree sweeps between vertices
	float angle = 0; //the starting angle for the circule
	float sbksshftX = 9.35; //represents the value by which we shift the circles representing Starbucks along the X axis
	float sbksshftY = 19.6; //represents the value by which we shift the circles representing Starbucks along the Y axis
	int radius = 2.20; //the radius of the primary circle used to represent Starbucks; all shading also uses a percentage of this value to give depth

    glClear(GL_COLOR_BUFFER_BIT);  /*clear the window */

	//first up, some general concourse work, including an entrance or two, as well as the tiger transit bus stop
	//each general part of the concourse will be made of two triangles, of two different colors
	//draw all of one color first, then draw all of the other color second
	glColor3f(92/denomRGB,8/denomRGB,8/denomRGB); //color for the first triangle in each concourse path: deep ruby/maroon

	//LEFT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,24*sbr);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(3*sbr,24*sbr);
	glEnd();

	//UPPER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,24*sbr);
		glVertex2f(12*sbr,20*sbr);
		glVertex2f(12*sbr,24*sbr);
	glEnd();

	//MIDDLE VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(14*sbr,26*sbr);
		glVertex2f(10*sbr,12*sbr);
		glVertex2f(14*sbr,12*sbr);
	glEnd();

	//MIDDLE HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(12*sbr,12*sbr);
		glVertex2f(27*sbr,12*sbr);
		glVertex2f(12*sbr,16*sbr);
	glEnd();

	//RIGHT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(19*sbr,0*sbr);
		glVertex2f(23*sbr,14*sbr);
		glVertex2f(19*sbr,14*sbr);
	glEnd();

	//LOWER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,0*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(0*sbr,4*sbr);
	glEnd();

	glColor3f(92/denomRGB,8/denomRGB,8/denomRGB); //color for the second triangle in each concourse path; same as first color unless otherwise specified

	//LEFT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(3*sbr,4*sbr);
		glVertex2f(3*sbr,24*sbr);
	glEnd();

	//UPPER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,20*sbr);
		glVertex2f(12*sbr,20*sbr);
		glVertex2f(0*sbr,24*sbr);
	glEnd();

	//MIDDLE VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(10*sbr,12*sbr);
		glVertex2f(14*sbr,26*sbr);
		glVertex2f(10*sbr,26*sbr);
	glEnd();

	//MIDDLE HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(12*sbr,16*sbr);
		glVertex2f(27*sbr,12*sbr);
		glVertex2f(27*sbr,16*sbr);
	glEnd();

	//RIGHT VERTICAL
	glBegin(GL_TRIANGLES);
		glVertex2f(19*sbr,0*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(23*sbr,14*sbr);
	glEnd();

	//LOWER HORIZONTAL
	glBegin(GL_TRIANGLES);
		glVertex2f(0*sbr,4*sbr);
		glVertex2f(23*sbr,0*sbr);
		glVertex2f(23*sbr,4*sbr);
	glEnd();

	//tiger transit stop

	glColor3f(0/denomRGB,0/denomRGB,0/denomRGB); //color for tiger transit stop directly by the building: black
	buildGLRectangle(11.45,12.55,0,3.25);
	buildGLRectangle(7.45,14.55,0,0.5);

	//the greenspace
	//now drawn via drawAnimatedGrass; method called later?

	//basic outline of the student center itself
	glColor3f(161/denomRGB,161/denomRGB,161/denomRGB); //color for the basic outline of the SC: grey-ish

	glBegin(GL_POLYGON);
		glVertex2f(0*sbr,1*sbr);
		glVertex2f(5.75*sbr,1*sbr);
		glVertex2f(5.75*sbr,5*sbr);
		glVertex2f(0*sbr,5*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(5.75*sbr,2*sbr);
		glVertex2f(11*sbr,2*sbr);
		glVertex2f(11*sbr,3*sbr);
		glVertex2f(5.75*sbr,3*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(14*sbr,0*sbr);
		glVertex2f(17.75*sbr,0*sbr);
		glVertex2f(17.75*sbr,2.75*sbr);
		glVertex2f(14*sbr,2.75*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(17.75*sbr,2*sbr);
		glVertex2f(20.75*sbr,2*sbr);
		glVertex2f(20.75*sbr,10.75*sbr);
		glVertex2f(20.2*sbr,10.75*sbr);
		glVertex2f(20.2*sbr,12.5*sbr);
		glVertex2f(19.5*sbr,12.5*sbr);
		glVertex2f(19.5*sbr,13.5*sbr);
		glVertex2f(16*sbr,13.5*sbr);
		glVertex2f(16*sbr,14*sbr);
		glVertex2f(14.25*sbr,14*sbr);
		glVertex2f(14.25*sbr,12.5*sbr);
		glVertex2f(13.75*sbr,12.5*sbr);
		glVertex2f(13.75*sbr,13*sbr);
		glVertex2f(12*sbr,13*sbr);
		glVertex2f(12*sbr,12.75*sbr);
		glVertex2f(10.5*sbr,12.75*sbr);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex2f(2.25*sbr,2.75*sbr);
		glVertex2f(18*sbr,2.75*sbr);
		glVertex2f(18*sbr,12.5*sbr);
		glVertex2f(2.75*sbr,12.5*sbr);
		glVertex2f(2.75*sbr,10.75*sbr);
		glVertex2f(2.25*sbr,10.75*sbr);
		glVertex2f(2.25*sbr,6.25*sbr);
	glEnd(); 
	
	glBegin(GL_POLYGON);
		glVertex2f(2.5*sbr,12.5*sbr);
		glVertex2f(10.25*sbr,12.5*sbr);
		glVertex2f(10.25*sbr,15*sbr);
		glVertex2f(10.50*sbr,15*sbr);
		glVertex2f(10.50*sbr,21*sbr);
		glVertex2f(4.25*sbr,21*sbr);
		glVertex2f(4.25*sbr,20.5*sbr);
		glVertex2f(2.5*sbr,20.5*sbr);
	glEnd();
	
	glBegin(GL_POLYGON); // our circle; code via the Internet; represents current-day Starbucks
		for(angle; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();

	//and to give a little shading to the student center building itself
	glColor3f(173/denomRGB,66/denomRGB,0/denomRGB); //color for the primary shading of the SC: brownish-orange

	//angle = 0; //must reset the angle in order to get the second drawing done
	glBegin(GL_POLYGON); // step one to shade the Starbucks circle
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();
	buildGLRectangle(3,10,6,20); //primary shade: upper/main left side of SC
	buildGLRectangle(3,19.75,3.5,12); //primary shade: bottom-right side of SC
	buildGLRectangle(14.25,17.6,0.45,9.4); //primary shade: lower-right side of SC
	buildGLRectangle(0.5,5.25,2,4.3); //primary shade: lower left corner of SC

	//and some secondary shading
	glColor3f(112/denomRGB,36/denomRGB,0/denomRGB); //color for the secondary shading of the SC: brownish-orange

	glBegin(GL_POLYGON); // adding a little more shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();
	buildGLRectangle(3.25,9.75,6.25,19.75); //secondary shade: upper/main left side of SC
	buildGLRectangle(3.25,19.5,3.75,11.5); //secondary shade: middle-right side of SC
	buildGLRectangle(14.4,17.4,0.65,9.4); //secondary shade: lower-right side of SC
	buildGLRectangle(0.65,5.1,2.2,3.75); //secondary shade: lower left corner of SC

	//and tertiary shading?
	glColor3f(255/denomRGB,168/denomRGB,69/denomRGB); //color for the tertiary shading of the SC: brownish-orange

	glBegin(GL_POLYGON); // adding a final touch of shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();
	buildGLRectangle(3.35,9.7,6.3,19.7); //tertiary shade: upper/main left side of SC
	buildGLRectangle(3.35,19.3,3.85,11.4); //tertiary shade: middle-right side of SC
	buildGLRectangle(14.5,17.3,0.75,9.4); //tertiary shade: lower-right side of SC
	buildGLRectangle(0.85,5,2.35,3.9); //tertiary shade: lower left corner of SC
	
	glColor3f(255/denomRGB,217/denomRGB,173/denomRGB); //color for the quarternary shading of the SC: brownish-orange

	glBegin(GL_POLYGON); // adding a super final touch of shade to the Starbucks circle. maybe.
		radius = radius * 0.99;
		for(angle = 0; angle < 2*PI; angle += delta_theta)
		{
			glVertex2f( (radius*cos(angle) + sbksshftX)*sbr, (radius*sin(angle) + sbksshftY)*sbr);
		}
	glEnd();
	buildGLRectangle(3.65,8.7,7.1,18.9); //4th shade: upper/main left side of SC
	buildGLRectangle(3.65,19,4.05,11); //4th shade: middle-right side of SC
	buildGLRectangle(15,17,1.75,9); //4th shade: lower-right side of SC
	buildGLRectangle(1.85,4,2.75,3.5); //4th shade: lower left corner of SC
	
	//displayAnimatedArrows(); //this method is not called in assignment 2
	displayAnimatedGrass();
	drawPersonWithDirArrow(); //draw the person to be moved around

	glFlush();


 }


void main(int argc, char** argv)
{

/* Standard GLUT initialization */

    glutInit(&argc,argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB); /*as set by default*/
    glutInitWindowSize(500,500); /* 500 x 500 window by default*/
    glutInitWindowPosition(0,0); /* place window top left on display */
    glutCreateWindow("COMP-5/6400 Assignment 2"); /* window title */
	
	glutReshapeFunc(manageReshape); //defines what method to call when the user resizes a window; target function is defined above
	glutKeyboardFunc(manageNormalKeyInput);
	glutSpecialFunc(manageArrowKeyInput); //tells the program to be waiting for input from arrow keys; target function is defined above
    glutDisplayFunc(display); /* display callback invoked when window opened */

    myinit(); /* set attributes */

    glutMainLoop(); /* enter event loop */
}