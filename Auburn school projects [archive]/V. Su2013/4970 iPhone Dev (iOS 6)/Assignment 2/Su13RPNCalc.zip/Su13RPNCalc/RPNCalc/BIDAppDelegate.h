//
//  BIDAppDelegate.h
//  RPNCalc
//
//  Created by Richard Chapman on 9/12/12.
//  Copyright (c) 2012 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BIDViewController;

@interface BIDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BIDViewController *viewController;

@end
