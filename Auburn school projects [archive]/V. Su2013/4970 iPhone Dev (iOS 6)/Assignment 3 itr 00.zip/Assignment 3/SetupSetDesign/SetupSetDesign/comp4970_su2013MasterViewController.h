//
//  comp4970_su2013MasterViewController.h
//  SetupSetDesign
//
//  Created by A. E. Wallace on 05/7/13.
//  Copyright (c) 2013 A. E. Wallace. All rights reserved.
//

#import <UIKit/UIKit.h>

@class comp4970_su2013DetailViewController;

@interface comp4970_su2013MasterViewController : UITableViewController

@property (strong, nonatomic) comp4970_su2013DetailViewController *detailViewController;

@end
