//
//  comp4970_su2013DetailViewController.h
//  SetupSetDesign
//
//  Created by A. E. Wallace on 05/7/13.
//  Copyright (c) 2013 A. E. Wallace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface comp4970_su2013DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@end
