//
//  comp4970_su2013AppDelegate.h
//  SetupSetDesign
//
//  Created by A. E. Wallace on 05/7/13.
//  Copyright (c) 2013 A. E. Wallace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface comp4970_su2013AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *navigationController;

@end
