import java.util.Random;

public class WordPhraseProducer
{
	Random decision = new Random();
	ArrayList<String> potentialSeeds = new ArrayList<String>();
	
	//empty constructor
	public WordPhraseProducer()
		{}

	//decides which character will be chosen from a range of "m" choices
	//returns decision as an int to go directly to an index
	public int chooseOpt(int mChoices)
	{
		return decision.nextInt(mChoices);
	}
	
	public String seedChoice(int select)
	{
		//code for returning one of the seed choices goes here
		//pair with chooseOpt
	}
		
}