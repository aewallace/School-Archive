//main class for user interaction

public class aew0024Assign3
{
	/*
	*@param k : the minimum number of characters to choose as
	* ...a seed from "source". Also, check for k>0; else error.
	*@param length : The tentative length of "result". Also, check for length>0; else error.
	*@param source : the name of the source file
	*@param result : the name of the output file
	*/
	public static void main(int k, int length, String source, String result)
	{
	WordPhraseProducer workWPD = new WordPhraseProducer();
	String fileRead, fileWrite;
	if (k < 0) {
		System.out.println("The target seed length is not a valid target.");
		return;
		}
	if (length < 0){
		System.out.println("The target output length is not a valid target.");
		return;
		}
	if (source == null || source.length() < 0)
		{
		//do something
		}
	if (result == null || result.length() < 0)
		{
		//do something
		}
	//do this if everything checks out fine
	}


}