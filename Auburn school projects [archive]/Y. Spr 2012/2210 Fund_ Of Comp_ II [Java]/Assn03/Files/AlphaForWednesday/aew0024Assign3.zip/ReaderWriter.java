//use for general reading and writing of files


public class ReaderWriter
{
	String writeOut = "";
	
	//will open the input file for use.
	public boolean openFile(String fileName)
	{
	}

	public void addToWrite(String addition)
	{
		writeOut += addition;
	}

}