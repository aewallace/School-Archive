   import java.util.Scanner;
   
	/**
    * Calculates the sum and average of three inputs via standard I/O.
    *
    * @author ____________________
    * @version 8-27-2010
    */
   public class AverageOfThree {
   
      /**
       * Calculates the sum and average of three inputs via standard I/O.
       *
       * @param args User-defined command line arguments (not used).
       */
      public static void main(String[] args) {
      
      	// do not change variable types
         int sum = 0;
         Scanner NumberInput = new Scanner(System.in);  
      	
         System.out.println("This program calculates the sum and average "
            + "of three integers.");
            
         // get numerical input from user
         System.out.print("Enter the first number: ");
         sum+= NumberInput.nextInt();
         System.out.print("Enter the second number: ");
         sum= NumberInput.nextInt();
         System.out.print("Enter the third number: ");
         sum= NumberInput.nextInt();
         
      	// display sum
         System.out.println("\r\n \r\nThe sum of your input is " + sum);
      	
      	//display average
         System.out.println("The average of your input is " + sum / 3);
      }
   }