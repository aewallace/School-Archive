/**
*This is used to help organize, say, a grocery store.
* It accepts categories for different items, and helps with calculation
* of total price for each given item. This is the potential front end.
*
*@author Albert Wallace -- section 003
*@version 9/28/2011
*/

public class GroceryList {
	
	
	/**
	*This is the main method that will be automatically executed
	* to do all of the front end work for the grocery program.
	*
	*@param args Not used.
	*/
	public static void main(String[] args) {
	
	}

}