/**
*This is used to help organize, say, a grocery store.
* It accepts categories for different items, and helps with calculation
* of total price for each given item.
*
*@author Albert Wallace -- section 003
*@version 9/28/2011
*/
public class GroceryItem {


	//...Names for categories of grocery goods.
		/**
		*General products that have no specific category.
		*/
	public static final String GENERAL = "General";
		/**
		*Represents the produce category of products.
		*/
	public static final String PRODUCE = "Produce";
		/**
		*Represents refrigerated goods.
		*/
	public static final String REFRIGERATED = "Refrigerated";
		/**
		*Represents items that need to remain fully frozen.
		*/
	public static final String FROZEN = "Frozen";
	
	//other variables
	private String nameOfItem;
	
	/**
	*Constructor to store information about each item. Defaults to a
	* predefined item category and generic name if none are provided.
	*
	*@param nameOfItem the name of each given item
	*
	*@param itemCategory the category into which each item falls.
	*/
	public GroceryItem(String potentialName, String itemCategory)
		{
		if (itemCategory.equals(GENERAL))
			{
			}
		else if (itemCategory.equals(PRODUCE))
			{
			}
		else if (itemCategory.equals(REFRIGERATED))
			{
			}
		else if (itemCategory.equals(FROZEN))
			{
			}
		else
			{
			}
		
		
		
		
		}
		
		/**
		*Action method. Changes the name of the item in question.
		*
		*@param nameChange the potential new name of the item
		*/
	public void setName(String nameChange) 
		{
		
		}
		
		/**
		*Query method. Returns the current name of the item in question.
		*
		*@return returns the name of the item in question.
		*/
	public String getName()
		{
		return null; //edit from here
		}
		
		/**
		*Action method. Sets the base price of the item in question, and
		* returns how successful the process was.
		*
		*@param potentialPrice the potential base price for the item
		*
		*@return how successful the process was, defined by integers.
		*/
	public int setBasePrice(double potentialPrice)
		{
		return 0;
		}
		
		/**
		*Query method. Returns the base price set for a given item.
		*
		*@return returns the base price of the item in question.
		*/
	public double getBasePrice()
		{
		return 0;
		}
		
		/**
		*Action and calculation method. Used to calculate the
		* total price, including fees and the taxes (applied after
		* fees, where applicable).
		*
		*@param localTaxRate the local tax rate used for applying
		* the appropriate tax percentage
		*
		*@return returns the price, or a "status number" if setting
		* was not successful.
		*/
	public double calculateTotalPrice(double localTaxRate)
		{
		return 0;
		}
		
		/**
		*Action method. Sets or changes the product category applied
		* to a given item.
		*
		*@param categoryChange the potential new category being set
		*
		*@return returns how successful the setting process was
		*/
	public boolean setCategory(String categoryChange)
		{
		return false;
		}
		
		/**
		*Query method. Used to obtain the current category for
		* a given item.
		*
		*@return returns the category currently set for the item
		*/
	public String getCategory()
		{
		return null;
		}
		
		/**
		*The requisite toString method. Nicely formats output for us.
		*
		*@return returns all the information set about an item that
		* we might want to see.
		*/
	public String toString()
		{
		return null;
		}


}