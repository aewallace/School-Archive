   import java.util.Scanner;
   
   /**
    * Obtains a set of numbers from the user until the user enters
    * 0. Information is then printed about each number that was entered 
    * including whether it was even or odd, and positive or negative.
    *
    * @author ________
    * @version ________
    */
   public class NumberList {
   
      /**
       * Obtains a set of numbers from the user until the user enters
   	 * 0. Information is then printed about each number that was entered 
    	 * including whether it was even or odd, and positive or negative.
   	 *
       * @param args - Standard commandline arguments
       */
      public static void main(String[] args) {
         /*
      	Delete this multi-line comment.
      	The comments below are meant to help you, but Web-CAT will only
      	grade the output of your program. You must use an ArrayList, however,
      	for full credit. Each comment below does not necessarily correspond
      	to a single line of code.
      	*/
      	
         String input = "";
         Scanner in = new Scanner(System.in);
         
         // declare and instantiate ArrayList with generic type <NumberOperations>
              
         // prompt user for set of numbers
         // get first line of user input
         // while the input is not "0"
            // add NumberOperations object to array based on user input
            // get new user input
         
         
         // iterate through ArrayList from beginning to end and print each object
      }
   }