import math

def determinePrimality(ceilingOfNumbersToTest):

    if ceilingOfNumbersToTest < 2: #if the ceiling is less than 2, then there are no primes to display (0 and 1 are not prime) 
        return []
    else:
        ceilingOfNumbersToTest = ceilingOfNumbersToTest + 1
        
        # CITATION: Sieve of Eratosthenes
        # Create list of all numbers up to max
        # Start with first prime
        # Strike all multiples 
        # repeat for next un-struck number in list
        
        #set up initial matrix
        originalListOfNumbers = [False, False] #marks 0 and 1 as false -- i.e., NOT as primes
        currentIterationOfLoop = 1 #Iteration zero is a valid iteration, consistent with indices in Python
        while currentIterationOfLoop < ceilingOfNumbersToTest: #for the rest of the numbers
            originalListOfNumbers.append(True)
            currentIterationOfLoop = currentIterationOfLoop + 1
        #end setup of matrix
        
        
        #mark out all multiples, leaving the primes as FALSE, and determine count of primes
        
        countOfPrimesAfterCheckingRange = ceilingOfNumbersToTest - 2 #we will decrement this number every time
        for currentIndexInTotalRange in range(2, int(math.sqrt(ceilingOfNumbersToTest) + 1)): #
            if originalListOfNumbers[currentIndexInTotalRange]: #
                firstMultipleToCheck = 2 * currentIndexInTotalRange
                for multipleOfPrime in range(firstMultipleToCheck, ceilingOfNumbersToTest, currentIndexInTotalRange): #must set the multiples of the prime as NOT PRIME -- false
                    if originalListOfNumbers[multipleOfPrime]:
                        originalListOfNumbers[multipleOfPrime] = False
                        countOfPrimesAfterCheckingRange = countOfPrimesAfterCheckingRange - 1 #
                        
        #all multiples should have been set as prime -- FALSE -- while primes remain as TRUE
        #we should also have a count of the number of primes available to us
        
        #makes a list/matrix/array the size of all the primes to be printed -- based on the count determined above
        finalListOfPrimes = [] #create empty list...
        currentIterationOfLoop = 0 #Iteration zero is a valid iteration, consistent with indices in Python
        while currentIterationOfLoop < countOfPrimesAfterCheckingRange: #...and for all the numbers...
            finalListOfPrimes.append(0) #...add a zero, one by one, to instantiate the array of primes
            currentIterationOfLoop = currentIterationOfLoop + 1
        #the array should now be instantiated with zeroes
        
        #
        indexInfinalListOfPrimes = 0 #
        for eachNumberInTheOriginalRange in range (0, ceilingOfNumbersToTest): #
            if originalListOfNumbers[eachNumberInTheOriginalRange]: #
                finalListOfPrimes[indexInfinalListOfPrimes] = eachNumberInTheOriginalRange #
                indexInfinalListOfPrimes = indexInfinalListOfPrimes + 1 #
                
        return finalListOfPrimes #return the list of primes


if __name__ == '__main__':
    x = int(raw_input("input a value "))    
    print "The primes are "
    print determinePrimality(x)

                
